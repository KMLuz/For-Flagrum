"""Reader for Forspoken strand hair (.gmdl_hair). Reads only what a preview needs: the hair groups and the
points of each strand. Positions are in game axes (Y up, metres).

Layout (version 20220420), worked out from hu000_100 and hu000_110:
    u32 version, char[256] material uri, scalp parameters, u16 bone count at 0x12E,
    bones (char[64] name + u32) from 0x130, fixed-size fields, u32 group count, then per group:
        char[256] name, 190 bytes of parameters (LOD range 41 bytes before the count), u32 strand count,
        strands: u32 flags, u32 n, n * float3 position, n * u32 packed direction, n * 16 bytes skinning,
                 8 floats, n * u16
"""
import re
import struct

from .glb import FskError

VERSION = 20220420
_BONE_RECORD = 68
_GROUP_HEADER = 446
_STRAND_FIXED = 8 + 32
_STRAND_PER_POINT = 12 + 4 + 16 + 2


def _parse_groups(d, o, count):
    groups = []
    for _ in range(count):
        if o + _GROUP_HEADER + 4 > len(d):
            return None
        name = d[o:o + 256].split(b"\0")[0].decode("ascii", "replace")
        n_strands = struct.unpack_from("<I", d, o + _GROUP_HEADER)[0]
        lod_near, lod_far = struct.unpack_from("<2f", d, o + _GROUP_HEADER - 41)
        o += _GROUP_HEADER + 4
        strands = []
        for _ in range(n_strands):
            if o + 8 > len(d):
                return None
            n = struct.unpack_from("<I", d, o + 4)[0]
            end = o + _STRAND_FIXED + _STRAND_PER_POINT * n
            if not 0 < n <= 4096 or end > len(d):
                return None
            pts = struct.unpack_from(f"<{3 * n}f", d, o + 8)
            strands.append([pts[i:i + 3] for i in range(0, 3 * n, 3)])
            o = end
        groups.append({"name": name, "lod_near": lod_near, "lod_far": lod_far, "strands": strands})
    return groups, o


def read(path):
    """{"material": uri, "groups": [{"name", "lod_near", "lod_far", "strands": [[(x, y, z), ...], ...]}]}"""
    with open(path, "rb") as f:
        d = f.read()
    if len(d) < 0x130 or struct.unpack_from("<I", d, 0)[0] != VERSION:
        raise FskError("not a Forspoken hair file, or a version this add-on doesn't know")
    material = d[4:260].split(b"\0")[0].decode("ascii", "replace")
    o = 0x130 + struct.unpack_from("<H", d, 0x12E)[0] * _BONE_RECORD
    # Fixed-size fields sit between the bones and the groups. Instead of trusting their size, try each place a
    # group name could start and keep the one that reads the whole file exactly to its end.
    for m in re.finditer(rb"[A-Za-z_][A-Za-z0-9_]{0,63}\x00", d[o:o + 0x4000]):
        start = o + m.start() - 4
        if start < o:
            continue
        count = struct.unpack_from("<I", d, start)[0]
        if not 0 < count < 10000:
            continue
        res = _parse_groups(d, start + 4, count)
        if res and res[1] == len(d):
            return {"material": material, "groups": res[0]}
    raise FskError("couldn't read the hair groups in this file (unknown layout)")


def is_full_detail(group):
    """The LOD0 groups: the ones the game draws up close (the others are lower-detail copies)."""
    return group["lod_near"] <= 0.0
