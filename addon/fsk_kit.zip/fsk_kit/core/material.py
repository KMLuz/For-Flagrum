"""Material (.gmtl.gfxbin) helpers: texture slots, named parameters, same-size parameter edits."""
import os
import struct

from .glb import FskError
from .gfx.gmtl.gmtl import Gmtl
from .gfx.msgpack_reader import MessagePackReader

# the slots the add-on fills; each maps to one game map suffix
CORE_SLOTS = {
    "BaseColorTexture0": "_b",
    "NormalTexture0": "_n",
    "RoughnessTexture0": "_r",
    "SpecularTexture0": "_s",
    "OcclusionTexture0": "_o",
}


def uri_to_path(data_root, uri, ext=".gfxbin"):
    """data://asset/x/y.gmtl -> <data_root>/asset/x/y.gmtl.gfxbin"""
    uri = str(uri)
    if not uri.startswith("data://"):
        raise FskError(f"not a data:// URI: {uri}")
    return os.path.join(data_root, *uri[len("data://"):].split("/")) + ext


def read(path_or_bytes):
    data = open(path_or_bytes, "rb").read() if isinstance(path_or_bytes, str) else bytes(path_or_bytes)
    return Gmtl(MessagePackReader(data)), data


def texture_slots(mat):
    """{slot name: uri} for every texture the material samples."""
    return {t.shader_gen_name: t.uri for t in mat.textures if t.shader_gen_name}


def _skin_uniforms(mat):
    out = {}
    for u in mat.uniforms:
        nm = mat._unpack_string(u.name_offset)
        if nm.split(".")[0].startswith("WitchCHR"):
            out[nm.split(".")[-1]] = u
    return out


def parameters(mat):
    """{name: tuple(values)} of the material's own parameter block."""
    out = {}
    for k, u in _skin_uniforms(mat).items():
        n = max(1, u.size // 4)
        b = mat.buffers[u.buffer_index]
        out[k] = struct.unpack_from("<" + "f" * n, mat.gpubin, b.offset + u.offset)
    return out


def shader_block(mat):
    names = {mat._unpack_string(u.name_offset).split(".")[0] for u in mat.uniforms}
    return next((n for n in sorted(names) if n.startswith("WitchCHR")), None)


def set_parameters(data, edits):
    """Return a copy of the material bytes with named float parameters changed (same size)."""
    data = bytearray(data)
    mat = Gmtl(MessagePackReader(bytes(data)))
    base = data.find(mat.gpubin)
    if base < 0 or data.find(mat.gpubin, base + 1) >= 0:
        raise FskError("could not locate the material's value block uniquely")
    us = _skin_uniforms(mat)
    for k, vals in edits.items():
        vals = [float(v) for v in (vals if isinstance(vals, (list, tuple)) else [vals])]
        u = us.get(k)
        if u is None:
            raise FskError(f"material has no parameter '{k}'")
        n = max(1, u.size // 4)
        if len(vals) != n:
            raise FskError(f"{k} takes {n} value(s)")
        struct.pack_into("<" + "f" * n, data, base + mat.buffers[u.buffer_index].offset + u.offset, *vals)
    Gmtl(MessagePackReader(bytes(data)))
    return bytes(data)


def texture_entry_uris(tex_uri):
    """Flagrum replace URIs for one texture: base, _$m1, _$h (in that order)."""
    stem, ext = os.path.splitext(tex_uri)
    return [f"{stem}{ext}", f"{stem}_$m1{ext}", f"{stem}_$h{ext}"]
