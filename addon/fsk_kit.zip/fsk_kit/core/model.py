"""
fsk_model.py - byte-exact editor for Forspoken (Luminous, version 20220707) models.

The model file is kept as a lossless list of msgpack tokens. Untouched tokens are
written back with their original bytes, so a rebuild with no edits is byte-identical.
Edits replace individual field tokens or drop whole mesh spans; the gpubin is then
re-laid-out with the rules measured from vanilla Frey (models 000 and 100):

  - mesh order in the gpubin == mesh order in the model file
  - index buffer starts at align64(end of previous vertex buffer)
  - vertex buffer starts at align64(index end) + (64 if index end % 16 else 0)
  - streams inside a vertex buffer start at align16(end of previous stream)
  - vertex buffer size = align16(end of last stream) for new data; vanilla sizes kept
  - unknown region: count 0, size 0, offset = align64(vertex buffer end)
  - file length = align64(end of last vertex buffer); all padding is zero
  - 32-bit indices exactly when index count > 65535
"""
import struct

from .tokens import Tok, tokenize

VERSION = 20220707


def al(x, a):
    return (x + a - 1) // a * a


# ----------------------------------------------------------------------------- encoding

def enc_int(value, signed_family=False):
    v = int(value)
    if v >= 0 and not signed_family:
        if v < 0x80:
            return bytes([v])
        for code, fmt, lim in ((0xcc, "<B", 1 << 8), (0xcd, "<H", 1 << 16), (0xce, "<I", 1 << 32)):
            if v < lim:
                return bytes([code]) + struct.pack(fmt, v)
        return b"\xcf" + struct.pack("<Q", v)
    if -32 <= v < 0x80:
        return struct.pack("<b", v) if v < 0 else bytes([v])
    for code, fmt, lo, hi in ((0xd0, "<b", -128, 127), (0xd1, "<h", -32768, 32767),
                              (0xd2, "<i", -(1 << 31), (1 << 31) - 1)):
        if lo <= v <= hi:
            return bytes([code]) + struct.pack(fmt, v)
    return b"\xd3" + struct.pack("<q", v)


def enc_like(value, original: Tok):
    """Re-encode a value in the same family the game used for that token."""
    if original.kind == "float":
        return b"\xca" + struct.pack("<f", float(value))
    if original.kind == "bool":
        return b"\xc3" if value else b"\xc2"
    if original.kind == "str":
        return enc_str(value)
    if original.kind == "arr":
        n = int(value)
        return bytes([0x90 | n]) if n < 16 else b"\xdc" + struct.pack("<H", n)
    signed = 0xd0 <= original.code <= 0xd3
    return enc_int(value, signed_family=signed)


def enc_str(s):
    if s == "":
        return b"\xa0"
    data = s.encode("utf-8") + b"\x00"
    if len(data) < 32:
        return bytes([0xa0 | len(data)]) + data
    if len(data) < 256:
        return b"\xd9" + bytes([len(data)]) + data
    return b"\xda" + struct.pack("<H", len(data)) + data


def tok_value(t: Tok):
    if t.kind == "str":
        return t.value[:-1].decode("utf-8") if t.value else ""
    return t.value


# ----------------------------------------------------------------------------- parsing

class Cursor:
    def __init__(self, toks):
        self.t, self.i = toks, 0

    def read(self):
        """Mirror of the addon's MessagePackReader.read(): one value, maps whole."""
        tok = self.t[self.i]
        self.i += 1
        if tok.kind == "map":
            out = {}
            for _ in range(tok.value):
                k, v = self.read(), self.read()
                out[k] = v
            return out
        return tok_value(tok)

    def field(self):
        """Read one scalar and return (value, token index)."""
        idx = self.i
        return self.read(), idx


class Mesh:
    """A mesh's token span plus the token index of every field the rebuilder edits."""

    def __init__(self):
        self.f = {}          # field name -> token index
        self.v = {}          # field name -> value
        self.streams = []    # dicts: slot, type, stride, offset (+ offset token index), elements
        self.parts = []      # dicts: parts_id, start, count (+ token indices)
        self.start = self.end = None

    def __getattr__(self, k):
        v = self.__dict__.get("v", {})
        if k in v:
            return v[k]
        raise AttributeError(k)


def _rf(c, mesh, name):
    val, idx = c.field()
    mesh.f[name], mesh.v[name] = idx, val
    return val


def parse_mesh(c):
    me = Mesh()
    me.start = c.i
    _rf(c, me, "name")
    _rf(c, me, "vertex_layout_type")
    _rf(c, me, "unknown2")
    me.f["aabb"] = c.i
    me.v["aabb"] = [c.read() for _ in range(6)]
    _rf(c, me, "is_oriented_bb")
    me.f["obb"] = c.i
    me.v["obb"] = [c.read() for _ in range(12)]
    for k in ("primitive_type", "face_index_count", "face_index_type", "gpubin_index",
              "face_index_offset", "face_index_size", "vertex_count"):
        _rf(c, me, k)
    n_streams, me.f["stream_count"] = c.field()
    for _ in range(n_streams):
        s = {}
        s["slot"], s["type"], s["stride"] = c.read(), c.read(), c.read()
        s["offset"], s["offset_idx"] = c.field()
        n_el = c.read()
        s["elements"] = [(c.read(), c.read(), c.read()) for _ in range(n_el)]
        me.streams.append(s)
    _rf(c, me, "vertex_buffer_offset")
    _rf(c, me, "vertex_buffer_size")
    n_sub, me.f["subgeometry_count"] = c.field()
    for _ in range(n_sub):
        for _ in range(6 + 4):
            c.read()
    for k in ("unknown6", "unknown_offset", "unknown_size", "material_hash", "draw_priority_offset",
              "unknown7", "unknown8", "lod_near", "lod_far", "lod_fade", "parts_id"):
        _rf(c, me, k)
    n_parts, me.f["parts_count"] = c.field()
    for _ in range(n_parts):
        p = {}
        p["parts_id"], p["parts_id_idx"] = c.field()
        p["start"], p["start_idx"] = c.field()
        p["count"], p["count_idx"] = c.field()
        me.parts.append(p)
    for k in ("unknown9", "flags", "unknown10", "breakable_bone_index", "low_lod_shadow_cascade_no"):
        _rf(c, me, k)
    me.end = c.i
    return me


class Model:
    def __init__(self, data: bytes):
        self.toks = tokenize(data)
        c = Cursor(self.toks)
        self.version = c.read()
        if self.version != VERSION:
            raise ValueError(f"not a Forspoken model (version {self.version})")
        self.dependencies = c.read()
        n_hash = c.read()
        self.hashes = [c.read() for _ in range(n_hash)]
        self.aabb_idx = c.i
        for _ in range(6):
            c.read()
        n_bones = c.read()
        self.bones = []
        for _ in range(n_bones):
            self.bones.append(c.read())
            c.read(); c.read()                       # lod_index, unique_index
        n_nodes = c.read()
        for ni in range(n_nodes):
            for _ in range(12):
                c.read()
            if ni:
                c.read()
            c.read(); c.read(); c.read(); c.read()   # name, unknown2-4
        c.read()                                     # unknown float
        self.gpubin_count = c.read()
        for _ in range(self.gpubin_count):
            c.read()
        n_objects = c.read()
        self.objects = []
        for oi in range(n_objects):
            obj = {"unknown": c.read() if oi else False, "name": c.read()}
            n_clusters = c.read()
            obj["clusters"] = [c.read() for _ in range(n_clusters)]
            n_meshes, obj["count_idx"] = c.field()
            obj["meshes"] = [parse_mesh(c) for _ in range(n_meshes)]
            self.objects.append(obj)
        c.read()                                     # unknown2
        self.name = c.read()
        n_parts = c.read()
        self.parts = {}
        for _ in range(n_parts):
            name, pid = c.read(), c.read()
            c.read(); c.read()
            self.parts[pid] = name
        for _ in range(5):
            c.read()
        n_sizes = c.read()
        self.size_idx = []
        for _ in range(n_sizes):
            _, idx = c.field()
            self.size_idx.append(idx)
        if c.i != len(self.toks):
            raise ValueError(f"{len(self.toks) - c.i} trailing tokens - parse drifted")

    def meshes(self):
        for oi, obj in enumerate(self.objects):
            for mi, me in enumerate(obj["meshes"]):
                yield f"{oi}.{mi:03d} {me.name}", me

    # ------------------------------------------------------------------ rebuild

    def rebuild(self, gpubin: bytes, remove=lambda label, me: False, replace=None):
        """
        Returns (model_bytes, gpubin_bytes).
        remove(label, mesh) -> True drops that mesh entirely.
        replace: optional {label: dict(ib, vb, stream_offsets, vertex_count, index_size, aabb, obb)}
                 for meshes whose geometry is new. Index width must follow the vanilla
                 rule (32-bit iff index count > 65535); pack_geometry() does that.
        """
        replace = replace or {}
        if self.gpubin_count != 1:
            raise NotImplementedError("multi-gpubin models not handled yet")

        edits, dropped = {}, []
        out = bytearray()
        for oi, obj in enumerate(self.objects):
            kept = 0
            for mi, me in enumerate(obj["meshes"]):
                label = f"{oi}.{mi:03d} {me.name}"
                if remove(label, me):
                    dropped.append((me.start, me.end))
                    continue
                kept += 1
                if label in replace:
                    r = replace[label]
                    ib, vb, stream_offsets = r["ib"], r["vb"], r["stream_offsets"]
                else:
                    ib = gpubin[me.face_index_offset:me.face_index_offset + me.face_index_size]
                    vb = gpubin[me.vertex_buffer_offset:me.vertex_buffer_offset + me.vertex_buffer_size]
                    stream_offsets = None
                ib_off = al(len(out), 64)
                out += bytes(ib_off - len(out)) + ib
                ib_end = len(out)
                vb_off = al(ib_end, 64) + (64 if ib_end % 16 else 0)
                out += bytes(vb_off - len(out)) + vb
                set_ = lambda name, val: edits.__setitem__(me.f[name], enc_like(val, self.toks[me.f[name]]))
                set_("face_index_offset", ib_off)
                set_("vertex_buffer_offset", vb_off)
                set_("unknown_offset", al(vb_off + len(vb), 64))
                if label in replace:
                    isize = r["index_size"]
                    count = len(ib) // isize
                    set_("face_index_size", len(ib))
                    set_("face_index_count", count)
                    set_("vertex_buffer_size", len(vb))
                    for s, off in zip(me.streams, stream_offsets):
                        edits[s["offset_idx"]] = enc_like(off, self.toks[s["offset_idx"]])
                    set_("vertex_count", r["vertex_count"])
                    set_("face_index_type", 1 if count > 65535 else 0)
                    for p in me.parts:
                        edits[p["count_idx"]] = enc_like(count - p["start"], self.toks[p["count_idx"]])
                    for k, n in (("aabb", 6), ("obb", 12)):
                        if k in r:
                            for j in range(n):
                                ti = me.f[k] + j
                                edits[ti] = enc_like(r[k][j], self.toks[ti])
            if kept != len(obj["meshes"]):
                edits[obj["count_idx"]] = enc_like(kept, self.toks[obj["count_idx"]])
        out += bytes(al(len(out), 64) - len(out))
        edits[self.size_idx[0]] = enc_like(len(out), self.toks[self.size_idx[0]])

        model = bytearray()
        drop_iter = sorted(dropped)
        i, d = 0, 0
        while i < len(self.toks):
            if d < len(drop_iter) and i == drop_iter[d][0]:
                i = drop_iter[d][1]
                d += 1
                continue
            model += edits.get(i, self.toks[i].raw)
            i += 1
        return bytes(model), bytes(out)


# ----------------------------------------------------------------------------- geometry packing

def pack_geometry(streams, vertex_count, indices, positions, is_oriented_bb):
    """
    streams: list of per-stream vertex bytes (already in the mesh's own element layout),
    in slot order. Returns the replace-dict for Model.rebuild().
    """
    import numpy as np
    vb = bytearray()
    offsets = []
    for data in streams:
        vb += bytes(al(len(vb), 16) - len(vb))
        offsets.append(len(vb))
        vb += data
    vb += bytes(al(len(vb), 16) - len(vb))
    idx = np.asarray(indices, dtype=np.uint32).ravel()
    wide = idx.size > 65535
    if not wide and idx.max() > 65535:
        raise ValueError("more than 65535 vertices needs more than 65535 indices in this format")
    ib = idx.astype(np.uint32 if wide else np.uint16).tobytes()
    p = np.asarray(positions, dtype=np.float32)
    lo, hi = p.min(0), p.max(0)
    aabb = [*lo, *hi]
    if is_oriented_bb:
        c, h = (lo + hi) / 2, (hi - lo) / 2
        obb = [*c, h[0], 0, 0, 0, h[1], 0, 0, 0, h[2]]
    else:
        obb = [*lo, *hi, 0, 0, 0, 0, 0, 0]
    return {"ib": ib, "vb": bytes(vb), "stream_offsets": offsets, "vertex_count": vertex_count,
            "index_size": 4 if wide else 2, "aabb": [float(x) for x in aabb], "obb": [float(x) for x in obb]}
