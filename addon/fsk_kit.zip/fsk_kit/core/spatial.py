"""Numpy-only spatial queries (Blender's Python has no scipy).

PointGrid answers "which points are within tol of q" exactly, using a hash grid whose cell size is
2*tol, so the tol-ball around any query touches at most 2x2x2 cells. nearest() is an exact brute-force
nearest neighbour, chunked, for the few thousand queries the builder needs it for.
"""
import numpy as np

_OFF = 1 << 20          # cell coordinates are offset into [0, 2^21) per axis -> fits one int64 code


def _codes(cells):
    c = cells + _OFF
    return (c[:, 0] << 42) | (c[:, 1] << 21) | c[:, 2]


class PointGrid:
    def __init__(self, P, tol):
        self.P = np.asarray(P, np.float64)
        self.tol = float(tol)
        self.cell = 2.0 * self.tol
        codes = _codes(np.floor(self.P / self.cell).astype(np.int64))
        self.order = np.argsort(codes, kind="stable")
        self.sorted = codes[self.order]

    def within(self, Q, k=None, chunk=40000):
        """For each query: indices of points with distance < tol, nearest first (ties by index).
        Returns (dist, idx) arrays of shape (m, K) padded with (inf, -1). K = k or the max found."""
        Q = np.asarray(Q, np.float64)
        dist_out, idx_out = [], []
        for s in range(0, len(Q), chunk):
            q = Q[s:s + chunk]
            base = np.floor((q - self.tol) / self.cell).astype(np.int64)
            cand = []
            for dx in (0, 1):
                for dy in (0, 1):
                    for dz in (0, 1):
                        c = _codes(base + np.array([dx, dy, dz]))
                        lo = np.searchsorted(self.sorted, c, "left")
                        hi = np.searchsorted(self.sorted, c, "right")
                        width = int((hi - lo).max()) if len(c) else 0
                        for r in range(width):
                            pos = lo + r
                            ok = pos < hi
                            col = np.full(len(q), -1, np.int64)
                            col[ok] = self.order[pos[ok]]
                            cand.append(col)
            if not cand:
                dist_out.append(np.full((len(q), 1), np.inf)); idx_out.append(np.full((len(q), 1), -1, np.int64))
                continue
            C = np.stack(cand, 1)
            D = np.full(C.shape, np.inf)
            m = C >= 0
            diff = self.P[np.where(m, C, 0)] - q[:, None, :]
            D[m] = np.sqrt((diff ** 2).sum(-1))[m]
            D[D >= self.tol] = np.inf
            C = np.where(np.isfinite(D), C, np.iinfo(np.int64).max)
            o = np.lexsort((C, D), axis=1)                       # by distance, then index
            D = np.take_along_axis(D, o, 1); C = np.take_along_axis(C, o, 1)
            C[~np.isfinite(D)] = -1
            dist_out.append(D); idx_out.append(C)
        K = k or max(d.shape[1] for d in dist_out)
        pad = lambda a, v: np.pad(a[:, :K], ((0, 0), (0, max(0, K - a.shape[1]))), constant_values=v)
        return (np.vstack([pad(d, np.inf) for d in dist_out]),
                np.vstack([pad(i, -1) for i in idx_out]))

    def nearest_within(self, Q):
        """(dist, idx) of the nearest point within tol, (inf, -1) if none."""
        d, i = self.within(Q, k=1)
        return d[:, 0], i[:, 0]


def nearest(P, Q, chunk=2048):
    """Exact nearest point of P for every row of Q (brute force, chunked). Returns (dist, idx)."""
    P = np.asarray(P, np.float64); Q = np.asarray(Q, np.float64)
    pp = (P ** 2).sum(1)
    D = np.empty(len(Q)); I = np.empty(len(Q), np.int64)
    for s in range(0, len(Q), chunk):
        q = Q[s:s + chunk]
        d2 = pp[None, :] - 2.0 * q @ P.T + (q ** 2).sum(1)[:, None]
        j = np.argmin(d2, 1)
        I[s:s + chunk] = j
        D[s:s + chunk] = np.sqrt(np.maximum(((P[j] - q) ** 2).sum(1), 0))
    return D, I
