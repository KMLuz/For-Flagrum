"""Flat, lossless msgpack tokenizer: every token keeps its exact original bytes."""
import struct

class Tok:
    __slots__ = ("kind", "value", "raw", "code")
    def __init__(self, kind, value, raw, code):
        self.kind, self.value, self.raw, self.code = kind, value, raw, code
    def __repr__(self):
        return f"Tok({self.kind},{self.value!r},0x{self.code:02x},{len(self.raw)}B)"

def tokenize(buf):
    toks, o, n = [], 0, len(buf)
    while o < n:
        c = buf[o]; s = o; o += 1
        if c <= 0x7f: kind, v = "int", c
        elif 0x80 <= c <= 0x8f: kind, v = "map", c & 0x0f
        elif 0x90 <= c <= 0x9f: kind, v = "arr", c & 0x0f
        elif 0xa0 <= c <= 0xbf:
            L = c & 0x1f; kind, v = "str", buf[o:o+L]; o += L
        elif c == 0xc0: kind, v = "nil", None
        elif c in (0xc2, 0xc3): kind, v = "bool", c == 0xc3
        elif c in (0xc4, 0xc5, 0xc6):
            w = {0xc4:1,0xc5:2,0xc6:4}[c]; L = int.from_bytes(buf[o:o+w],"little"); o += w
            kind, v = "bin", buf[o:o+L]; o += L
        elif c == 0xca: kind, v = "float", struct.unpack_from("<f", buf, o)[0]; o += 4
        elif c == 0xcb: kind, v = "float", struct.unpack_from("<d", buf, o)[0]; o += 8
        elif 0xcc <= c <= 0xcf:
            w = 1 << (c - 0xcc); kind, v = "int", int.from_bytes(buf[o:o+w],"little"); o += w
        elif 0xd0 <= c <= 0xd3:
            w = 1 << (c - 0xd0); kind, v = "int", int.from_bytes(buf[o:o+w],"little",signed=True); o += w
        elif c in (0xd9, 0xda, 0xdb):
            w = {0xd9:1,0xda:2,0xdb:4}[c]; L = int.from_bytes(buf[o:o+w],"little"); o += w
            kind, v = "str", buf[o:o+L]; o += L
        elif c in (0xdc, 0xdd):
            w = 2 if c == 0xdc else 4; kind, v = "arr", int.from_bytes(buf[o:o+w],"little"); o += w
        elif c in (0xde, 0xdf):
            w = 2 if c == 0xde else 4; kind, v = "map", int.from_bytes(buf[o:o+w],"little"); o += w
        elif c >= 0xe0: kind, v = "int", c - 0x100
        else:
            raise ValueError(f"unsupported msgpack code 0x{c:02x} at {s}")
        toks.append(Tok(kind, v, bytes(buf[s:o]), c))
    return toks
