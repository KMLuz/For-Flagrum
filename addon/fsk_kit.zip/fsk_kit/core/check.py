"""Independent validation of a built model (separate parser from the one that wrote it)."""
import os

import numpy as np

from .gfx.msgpack_reader import MessagePackReader
from .gfx.gmdl.gmdl import Gmdl

FORSPOKEN_VERSION = 20220707


def load(gfxbin_path):
    data = open(gfxbin_path, "rb").read()
    reader = MessagePackReader(data)
    model = Gmdl(reader)
    stem = gfxbin_path[: -len(".gmdl.gfxbin")]
    gpubins = {}
    for i in range(model.gpubin_count):
        path = f"{stem}_{i}.gpubin"
        gpubins[i] = open(path, "rb").read() if os.path.exists(path) else None
    return model, gpubins, reader.offset, len(data)


def all_meshes(model):
    for oi, mo in enumerate(model.mesh_objects):
        for mi, me in enumerate(mo.meshes):
            yield f"{oi}.{mi:03d} {me.name}", me


def check(gfxbin_path):
    errors, warnings = [], []
    try:
        model, gpubins, consumed, total = load(gfxbin_path)
    except Exception as exc:  # parse failure is the most important error of all
        return [f"model file failed to parse: {exc!r}"], [], None, None

    if consumed != total:
        errors.append(f"model file has {total - consumed} unread trailing bytes (parse drifted)")
    if model.header.version != FORSPOKEN_VERSION:
        errors.append(f"version {model.header.version}, expected {FORSPOKEN_VERSION} (XV-format file?)")

    for i, gp in gpubins.items():
        if gp is None:
            errors.append(f"gpubin {i} missing next to the model file")
        elif i < len(model.gpubin_sizes) and model.gpubin_sizes[i] != len(gp):
            errors.append(f"gpubin {i}: size table says {model.gpubin_sizes[i]}, file is {len(gp)}")
    if len(model.gpubin_sizes) != model.gpubin_count:
        errors.append(f"size table has {len(model.gpubin_sizes)} entries for {model.gpubin_count} gpubins")

    bone_count = len(model.bones)
    spans = {}
    for label, me in all_meshes(model):
        gp = gpubins.get(me.gpubin_index)
        if gp is None:
            errors.append(f"{label}: points at gpubin {me.gpubin_index}, which isn't available")
            continue
        n = len(gp)
        isize = 4 if me.face_index_type == 1 else 2

        # index buffer
        if me.face_index_offset % 64:
            errors.append(f"{label}: index buffer offset not 64-aligned")
        if me.face_index_size != me.face_index_count * isize:
            errors.append(f"{label}: index size {me.face_index_size} != count*{isize}")
        if (me.face_index_type == 1) != (me.face_index_count > 65535):
            warnings.append(f"{label}: index width differs from vanilla rule (32-bit iff >65535 indices)")
        if me.face_index_count % 3:
            errors.append(f"{label}: index count not a multiple of 3")
        if me.face_index_offset + me.face_index_size > n:
            errors.append(f"{label}: index buffer runs past end of gpubin")
            continue

        # vertex buffer + streams
        if me.vertex_buffer_offset % 64:
            errors.append(f"{label}: vertex buffer offset not 64-aligned")
        if me.vertex_buffer_offset + me.vertex_buffer_size > n:
            errors.append(f"{label}: vertex buffer runs past end of gpubin")
            continue
        for s in me.vertex_streams:
            if s.offset % 16:
                errors.append(f"{label}: stream {s.slot} offset not 16-aligned")
            if s.offset + s.stride * me.vertex_count > me.vertex_buffer_size:
                errors.append(f"{label}: stream {s.slot} runs past its vertex buffer")

        # unknown per-mesh region (empty on every vanilla Frey mesh)
        if me.unknown6 != 0 or me.unknown_size != 0:
            warnings.append(f"{label}: non-empty unknown region (count {me.unknown6}, size {me.unknown_size})")

        # mesh parts must sit inside the index range
        for p in me.parts:
            if p.start_index + p.index_count > me.face_index_count:
                errors.append(f"{label}: mesh-part entry covers {p.start_index}+{p.index_count}, "
                              f"mesh only has {me.face_index_count} indices")

        # indices must reference real vertices
        dt = np.uint32 if isize == 4 else np.uint16
        idx = np.frombuffer(gp, dtype=dt, count=me.face_index_count, offset=me.face_index_offset)
        if idx.size and idx.max() >= me.vertex_count:
            errors.append(f"{label}: index {int(idx.max())} >= vertex count {me.vertex_count}")
        tris = idx.reshape(-1, 3) if idx.size else idx.reshape(0, 3)
        live = int(np.count_nonzero((tris[:, 0] != tris[:, 1]) | (tris[:, 1] != tris[:, 2]))) if tris.size else 0

        # positions / weights from stream 0 when it has the usual layout
        s0 = me.vertex_streams[0]
        elems = {e.semantic: e for e in s0.elements}
        raw = np.frombuffer(gp, dtype=np.uint8, count=me.vertex_count * s0.stride,
                            offset=me.vertex_buffer_offset + s0.offset).reshape(me.vertex_count, s0.stride)
        if "POSITION0" in elems and int(elems["POSITION0"].format) == 0x10:
            o = elems["POSITION0"].offset
            pos = raw[:, o:o + 12].copy().view(np.float32).reshape(-1, 3)
            if not np.isfinite(pos).all():
                errors.append(f"{label}: NaN/inf vertex positions")
            elif me.vertex_count:
                lo, hi = np.array(me.AABB[0]), np.array(me.AABB[1])
                if (pos.min(0) < lo - 1e-3).any() or (pos.max(0) > hi + 1e-3).any():
                    warnings.append(f"{label}: vertices outside the mesh bounding box (may get culled)")
        for k in ("0", "1"):
            bi, bw = elems.get("BLENDINDICES" + k), elems.get("BLENDWEIGHT" + k)
            if bi is not None and int(bi.format) == 0x8:
                ids = raw[:, bi.offset:bi.offset + 8].copy().view(np.uint16)
                if bw is not None and int(bw.format) == 0xC:
                    w = raw[:, bw.offset:bw.offset + 4]
                    if (ids[w > 0] >= bone_count).any():
                        errors.append(f"{label}: weights on bone index >= {bone_count}")

        spans.setdefault(me.gpubin_index, []).append(
            (me.face_index_offset, me.vertex_buffer_offset + me.vertex_buffer_size, label))
        me._live_tris = live

    # no overlapping mesh data
    for gi, lst in spans.items():
        lst.sort()
        for (a0, a1, la), (b0, b1, lb) in zip(lst, lst[1:]):
            if b0 < a1:
                errors.append(f"gpubin {gi}: {lb} overlaps {la}")

    return errors, warnings, model, gpubins


def diff(model, gpubins, vmodel, vgpubins):
    out = []
    vm = dict(all_meshes(vmodel))
    for label, me in all_meshes(model):
        v = vm.get(label)
        if v is None:
            out.append(f"  + {label} (new mesh)")
            continue
        gp, vgp = gpubins[me.gpubin_index], vgpubins[v.gpubin_index]
        ib = gp[me.face_index_offset:me.face_index_offset + me.face_index_size]
        vib = vgp[v.face_index_offset:v.face_index_offset + v.face_index_size]
        vb = gp[me.vertex_buffer_offset:me.vertex_buffer_offset + me.vertex_buffer_size]
        vvb = vgp[v.vertex_buffer_offset:v.vertex_buffer_offset + v.vertex_buffer_size]
        what = [n for n, a, b in (("indices", ib, vib), ("vertices", vb, vvb)) if a != b]
        if what:
            out.append(f"  ~ {label}: {', '.join(what)} changed, live triangles "
                       f"{me._live_tris} (vanilla {v.face_index_count // 3})")
    for label in vm.keys() - dict(all_meshes(model)).keys():
        out.append(f"  - {label} (removed)")
    return out




def run_check(gmdl_path, vanilla_path=None):
    """Returns (ok, lines)."""
    errors, warnings, model, gpubins = check(gmdl_path)
    lines = []
    if model is not None:
        lines.append(f"{sum(1 for _ in all_meshes(model))} meshes, {len(model.bones)} bones, {model.gpubin_count} gpubin(s)")
    lines += [f"WARN  {w}" for w in warnings] + [f"ERROR {e}" for e in errors]
    if vanilla_path and model is not None:
        verr, _, vmodel, vgpubins = check(vanilla_path)
        if not verr:
            changes = diff(model, gpubins, vmodel, vgpubins)
            lines.append(f"differences from vanilla: {len(changes) or 'none'}")
    lines.append("RESULT: " + ("FAIL" if errors else "PASS"))
    return not errors, lines
