"""glTF binary reading and vertex conversion helpers."""
import json
import struct

import numpy as np


class FskError(Exception):
    """A problem the user has to fix (shown in Blender's report area)."""


COMP = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
WIDTH = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}


class Glb:
    def __init__(self, path):
        b = open(path, "rb").read()
        if b[:4] != b"glTF":
            raise FskError("not a .glb file (export as glTF Binary)")
        jl = struct.unpack_from("<I", b, 12)[0]
        self.j = json.loads(b[20:20 + jl])
        self.bin = b[20 + jl + 8:] if len(b) > 20 + jl else b""
        if "KHR_draco_mesh_compression" in self.j.get("extensionsUsed", []):
            raise FskError("the .glb uses Draco compression - turn Compression off in the exporter")

    def acc(self, i):
        a = self.j["accessors"][i]
        bv = self.j["bufferViews"][a["bufferView"]]
        dt, n = COMP[a["componentType"]], WIDTH[a["type"]]
        off = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
        size = np.dtype(dt).itemsize * n
        stride = bv.get("byteStride", 0) or size
        raw = np.frombuffer(self.bin, np.uint8, (a["count"] - 1) * stride + size, off)
        idx = (np.arange(a["count"])[:, None] * stride + np.arange(size)[None, :])
        arr = raw[idx].copy().view(dt).reshape(a["count"], n)
        if a.get("normalized"):
            arr = arr.astype(np.float64) / np.iinfo(dt).max
        return arr


def compute_tangents(P, N, UV, tris):
    t = tris.reshape(-1, 3)
    e1, e2 = P[t[:, 1]] - P[t[:, 0]], P[t[:, 2]] - P[t[:, 0]]
    d1, d2 = UV[t[:, 1]] - UV[t[:, 0]], UV[t[:, 2]] - UV[t[:, 0]]
    det = d1[:, 0] * d2[:, 1] - d2[:, 0] * d1[:, 1]
    r = np.where(np.abs(det) < 1e-12, 0.0, 1.0 / np.where(np.abs(det) < 1e-12, 1.0, det))
    sdir = (e1 * d2[:, 1:2] - e2 * d1[:, 1:2]) * r[:, None]
    tdir = (e2 * d1[:, 0:1] - e1 * d2[:, 0:1]) * r[:, None]
    T, B = np.zeros_like(P), np.zeros_like(P)
    for k in range(3):
        np.add.at(T, t[:, k], sdir)
        np.add.at(B, t[:, k], tdir)
    N = N / np.maximum(np.linalg.norm(N, axis=1, keepdims=True), 1e-12)
    T = T - N * (N * T).sum(1, keepdims=True)
    bad = np.linalg.norm(T, axis=1) < 1e-9
    if bad.any():
        helper = np.where(np.abs(N[bad, 1:2]) < 0.9, [[0.0, 1.0, 0.0]], [[1.0, 0.0, 0.0]])
        T[bad] = np.cross(N[bad], helper)
    T /= np.maximum(np.linalg.norm(T, axis=1, keepdims=True), 1e-12)
    w = np.where((np.cross(N, T) * B).sum(1) < 0, -1.0, 1.0)
    return T, -w  # game stores the opposite handedness


def quantize_weights(J, W, max_influences=8):
    order = np.argsort(-W, axis=1)[:, :max_influences]
    J = np.take_along_axis(J, order, 1)
    W = np.take_along_axis(W, order, 1)
    W = np.where(W > 0, W, 0)
    s = W.sum(1, keepdims=True)
    if (s == 0).any():
        raise FskError(f"{int((s == 0).sum())} vertices have no weights - weight every vertex")
    W = W / s
    q = np.floor(W * 255 + 0.5).astype(np.int64)
    q[np.arange(len(q)), np.argmax(q, 1)] += 255 - q.sum(1)
    J = np.where(q > 0, J, 0)
    if J.shape[1] < 8:
        J = np.pad(J, ((0, 0), (0, 8 - J.shape[1])))
        q = np.pad(q, ((0, 0), (0, 8 - q.shape[1])))
    return J, q.astype(np.uint8)


