"""Plan and build a Forspoken model from the vanilla files plus exported meshes.

Rules (meshes are identified by geometry first, then by name):
  * a vanilla piece whose vertices all appear unchanged in the export     -> kept exactly as in the game
  * a vanilla piece that is partly in the export (edited)                 -> replaced by that export mesh
  * an export mesh that matches nothing (a new body)                      -> replaces the vanilla piece with
                                                                             the same name, or the one it is
                                                                             mapped to
  * a vanilla piece that is not in the export                             -> removed (all LODs + VEM copy)

A "piece" (group) is one (part, material) pair: its LODs and its VEM copy together.
Export meshes named  <name>__fsk_lod<k>  /  <name>__fsk_vem  feed LOD k / the VEM copy of <name>'s piece;
without them every LOD gets the LOD0 mesh.
"""
import collections
import os
import re

import numpy as np

from .glb import FskError, compute_tangents, quantize_weights
from .model import Model, pack_geometry, tok_value
from .spatial import PointGrid, nearest

TOL = 5e-5
SIZE = {0x10: 12, 0x8: 8, 0xC: 4, 0xE: 4, 0x1B: 4, 0x15: 8, 0x6: 8, 0x1A: 4}
VEM_FLAG = 0x4000000
LOD_SUFFIX = "__fsk_lod"
VEM_SUFFIX = "__fsk_vem"
COLLAR_Y = 1.535                      # head vertices below this are the collar (per-corner factor donors)
COPY_FROM_GAME = {"NORMAL0", "TANGENT0", "TEXCOORD1", "BLENDINDICES0", "BLENDINDICES1",
                  "BLENDWEIGHT0", "BLENDWEIGHT1", "NORMAL4FACTORS0", "NORMAL2FACTORS0"}
WEIGHT_SEMANTICS = {"BLENDINDICES0", "BLENDINDICES1", "BLENDWEIGHT0", "BLENDWEIGHT1"}


def base_name(k):
    """skin_body.003 -> skin_body ; skin_body__fsk_lod2 -> skin_body"""
    k = str(k)
    for suf in (LOD_SUFFIX, VEM_SUFFIX):
        if suf in k:
            k = k[:k.index(suf)]
    return re.sub(r"\.\d{3}$", "", k)


def is_variant(k):
    return LOD_SUFFIX in str(k) or VEM_SUFFIX in str(k)


# ------------------------------------------------------------------------------------------ glTF

def read_glb_meshes(glb):
    j = glb.j
    out = {}
    for node in j["nodes"]:
        if "mesh" not in node:
            continue
        joints = [j["nodes"][k].get("name") for k in j["skins"][node["skin"]]["joints"]] if "skin" in node else []
        P, N, U0, U1, JJ, WW, I = [], [], [], [], [], [], []
        base = 0
        for prim in j["meshes"][node["mesh"]]["primitives"]:
            if prim.get("mode", 4) != 4:
                raise FskError(f"'{node.get('name')}': only triangle meshes are supported")
            at = prim["attributes"]
            p = glb.acc(at["POSITION"]).astype(np.float64); n = len(p)
            P.append(p); N.append(glb.acc(at["NORMAL"]).astype(np.float64))
            U0.append(glb.acc(at["TEXCOORD_0"]).astype(np.float64) if "TEXCOORD_0" in at else np.zeros((n, 2)))
            U1.append(glb.acc(at["TEXCOORD_1"]).astype(np.float64) if "TEXCOORD_1" in at else np.zeros((n, 2)))
            js, ws, s = [], [], 0
            while f"JOINTS_{s}" in at:
                js.append(glb.acc(at[f"JOINTS_{s}"]).astype(np.int64)); ws.append(glb.acc(at[f"WEIGHTS_{s}"]).astype(np.float64)); s += 1
            JJ.append(np.hstack(js) if js else np.zeros((n, 4), np.int64)); WW.append(np.hstack(ws) if ws else np.zeros((n, 4)))
            I.append((glb.acc(prim["indices"]).ravel().astype(np.int64) if "indices" in prim else np.arange(n)) + base)
            base += n
        w = max(x.shape[1] for x in JJ)
        out[node.get("name")] = dict(P=np.vstack(P), N=np.vstack(N), U0=np.vstack(U0), U1=np.vstack(U1),
                                     J=np.vstack([np.pad(x, ((0, 0), (0, w - x.shape[1]))) for x in JJ]),
                                     W=np.vstack([np.pad(x, ((0, 0), (0, w - x.shape[1]))) for x in WW]),
                                     I=np.concatenate(I), joints=joints)
    return out


# ------------------------------------------------------------------------------------------ vanilla

class Vanilla:
    """One vanilla outfit model: gmdl + gpubin, grouped into pieces."""

    def __init__(self, gmdl_path):
        if not gmdl_path.endswith(".gmdl.gfxbin"):
            raise FskError(f"not a .gmdl.gfxbin file: {gmdl_path}")
        self.path = gmdl_path
        self.stem = os.path.basename(gmdl_path)[: -len(".gmdl.gfxbin")]
        gp = os.path.join(os.path.dirname(gmdl_path), f"{self.stem}_0.gpubin")
        if not os.path.exists(gp):
            raise FskError(f"vanilla gpubin missing next to the model: {gp}")
        self.model = Model(open(gmdl_path, "rb").read())
        self.gpubin = open(gp, "rb").read()
        self.deps = self.model.dependencies
        self.bone_index = {b: i for i, b in enumerate(self.model.bones)}
        self.meshes = list(self.model.meshes())
        self.by_label = dict(self.meshes)
        self.groups = collections.OrderedDict()
        for label, me in self.meshes:
            g = self.group_of(me)
            info = self.groups.setdefault(g, dict(name=me.name, material=self.material_uri(me), labels=[], lods=[], vems=[]))
            info["labels"].append(label)
            (info["vems"] if self.is_vem(me) else info["lods"]).append(label)
        for g, info in self.groups.items():
            meshes = [self.by_label[l] for l in info["lods"]]
            levels = sorted({me.lod_near for me in meshes})
            info["level_of"] = {l: levels.index(self.by_label[l].lod_near) for l in info["lods"]}
            info["lods"].sort(key=lambda l: (info["level_of"][l], l))
            # LOD0 meshes ("units"): one for most pieces, two for shoes (left/right), etc.
            info["units"] = [l for l in info["lods"] if info["level_of"][l] == 0 and self.by_label[l].lod_near == 0.0]
            info["unit_names"] = [self.by_label[l].name for l in info["units"]]
            info["name"] = info["unit_names"][0] if info["units"] else info["name"]
            info["display"] = " + ".join(dict.fromkeys(info["unit_names"])) or info["name"]
            info["lod0"] = info["units"][0] if len(info["units"]) == 1 else (info["units"][0] if info["units"] else None)
            info["tris"] = [sum(self.by_label[l].face_index_count // 3 for l in info["lods"] if info["level_of"][l] == k)
                            for k in range(len(levels))]
            vt = sum(self.by_label[l].face_index_count // 3 for l in info["vems"])
            info["vem_tris"] = [vt] if info["vems"] else []
            info["v0"] = sum(self.by_label[l].vertex_count for l in info["units"])
            info["track_of"] = self._tracks(info)
            levels_of = lambda l: "vem" if l in info["vems"] else f"lod{info['level_of'][l]}"
            info["track_tris"] = {u: collections.Counter() for u in info["units"]}
            info["combined_tris"] = collections.Counter()
            for l in info["labels"]:
                t = self.by_label[l].face_index_count // 3
                tr = info["track_of"][l]
                (info["track_tris"][tr] if tr is not None else info["combined_tris"])[levels_of(l)] += t
        self._pos = {}

    def _tracks(self, info):
        """Which LOD0 mesh ("unit") every mesh of the piece belongs to; None = it covers several (merged)."""
        units = info["units"]
        if len(units) <= 1:
            return {l: (units[0] if units else None) for l in info["labels"]}
        grids = {u: PointGrid(self.rows(self.by_label[u])[2], 0.005) for u in units}
        out = {}
        for l in info["labels"]:
            if l in units:
                out[l] = l
                continue
            P = self.rows(self.by_label[l])[2]
            fr = sorted(((float(np.isfinite(g.nearest_within(P)[0]).mean()), u) for u, g in grids.items()), reverse=True)
            (f1, u1), (f2, _) = fr[0], fr[1]
            out[l] = u1 if f1 >= 0.6 and f2 < 0.5 * f1 else None
        return out

    def is_vem(self, me):
        return bool(tok_value(self.model.toks[me.f["flags"]]) & VEM_FLAG)

    def material_uri(self, me):
        return str(self.deps.get(str(me.material_hash), str(me.material_hash)))

    def group_of(self, me):
        part = self.model.parts.get(me.parts_id, str(me.parts_id)).replace("parts_vem_", "parts_")
        return (part, self.material_uri(me).split("/")[-1])

    @staticmethod
    def key(g):
        return f"{g[0]}|{g[1]}"

    def group_by_key(self, key):
        return next((g for g in self.groups if self.key(g) == key), None)

    def ref_uri(self):
        return str(self.deps.get("ref"))

    def gpubin_uri(self):
        return str(next(v for v in self.deps.values() if str(v).endswith("_0.gpubin")))

    def rows(self, me):
        """Raw vertex rows per stream, element table, decoded positions and UV0."""
        rows = []
        for s in me.streams:
            a = np.frombuffer(self.gpubin, np.uint8, me.vertex_count * s["stride"], me.vertex_buffer_offset + s["offset"]).reshape(-1, s["stride"])
            rows.append(a)
        el = {}
        for si, s in enumerate(me.streams):
            for off, sem, fmt in s["elements"]:
                el[sem] = (si, off, fmt)
        si, off, _ = el["POSITION0"]
        pos = rows[si][:, off:off + 12].copy().view(np.float32).reshape(-1, 3).astype(np.float64)
        uv = None
        if "TEXCOORD0" in el:
            si, off, fmt = el["TEXCOORD0"]
            if fmt == 0x1B: uv = rows[si][:, off:off + 4].copy().view(np.uint16).reshape(-1, 2) / 65535.0
            elif fmt == 0x15: uv = rows[si][:, off:off + 8].copy().view(np.float32).reshape(-1, 2).astype(np.float64)
            elif fmt == 0x1A: uv = rows[si][:, off:off + 4].copy().view(np.float16).reshape(-1, 2).astype(np.float64)
        return rows, el, pos, uv

    def unit_positions(self, label):
        if label not in self._pos:
            self._pos[label] = self.rows(self.by_label[label])[2]
        return self._pos[label]


# ------------------------------------------------------------------------------------------ plan

class Plan:
    def __init__(self):
        self.action = collections.OrderedDict()   # group -> keep / replace / remove
        self.source = {}                          # single-mesh group -> (export name, vanilla lod0 label or None)
        self.unit_action = {}                     # LOD0 mesh label -> keep / replace / remove
        self.unit_source = {}                     # LOD0 mesh label -> (export name, vanilla label or None)
        self.reason = {}                          # group -> short text
        self.errors = []
        self.warnings = []


def make_plan(van, exp_positions, keep_vanilla=(), mapping=None):
    """exp_positions: {export name: (n,3) positions} for LOD0 meshes (variants are ignored here).
    keep_vanilla: group keys forced to keep. mapping: {export name: target} manual targets, where target is a
    group key, or "<group key>#<LOD0 mesh label>" for one mesh of a multi-mesh piece."""
    mapping = {k: v for k, v in (mapping or {}).items() if v}
    plan = Plan()
    ua, us, why = plan.unit_action, plan.unit_source, {}
    exp = {k: np.asarray(v, np.float64) for k, v in exp_positions.items() if not is_variant(k)}
    grids = {k: PointGrid(P, TOL) for k, P in exp.items() if len(P)}
    best = {}                                     # unit label -> (export name, fraction of its vertices found)
    for g, info in van.groups.items():
        for u in info["units"]:
            vpos = van.unit_positions(u)
            b, frac = None, 0.0
            for k, grid in grids.items():
                f = float(np.isfinite(grid.nearest_within(vpos)[0]).mean()) if len(vpos) else 0.0
                if f > frac:
                    b, frac = k, f
            best[u] = (b, frac)
    covers = collections.defaultdict(list)       # export name -> vanilla LOD0 meshes it fully contains
    for u, (k, f) in best.items():
        if k is not None and f >= 0.999:
            covers[k].append(u)
    nothing_added = {}                             # every export vertex sits on a vanilla vertex (splits are fine)
    for k, us_ in covers.items():
        V = np.vstack([van.unit_positions(u) for u in us_])
        nothing_added[k] = float(np.isfinite(PointGrid(V, TOL).nearest_within(exp[k])[0]).mean()) >= 0.999
    unchanged = lambda u: best[u][1] >= 0.999 and nothing_added.get(best[u][0], False)
    used = set()
    for g, info in van.groups.items():
        for u in info["units"]:
            k, f = best[u]
            if unchanged(u):
                ua[u], us[u], why[u] = "keep", (k, None), f"unchanged in '{k}'"; used.add(k)
            elif f >= 0.5:
                ua[u], us[u], why[u] = "replace", (k, u), f"edited: '{k}' ({f:.0%} of vanilla vertices kept)"; used.add(k)
            else:
                ua[u], why[u] = "remove", "not in export"
    # manual mapping wins over geometry
    for k, target in mapping.items():
        if k not in exp:
            continue
        gkey, _, ulabel = target.partition("#")
        g = van.group_by_key(gkey)
        if g is None:
            plan.errors.append(f"'{k}' is mapped to '{gkey}', which this outfit doesn't have"); continue
        units = van.groups[g]["units"]
        if ulabel:
            if ulabel not in units:
                plan.errors.append(f"'{k}' is mapped to a mesh this outfit doesn't have ({ulabel})"); continue
            u = ulabel
        elif len(units) == 1:
            u = units[0]
        else:
            plan.errors.append(f"'{k}': {van.groups[g]['display']} is several meshes - pick which one it replaces"); continue
        for ou in [ou for ou, src in us.items() if src[0] == k and ou != u]:
            ua[ou], why[ou] = "remove", "not in export"; us.pop(ou)
        vl = us[u][1] if us.get(u, (None,))[0] == k else None
        ua[u], us[u], why[u] = "replace", (k, vl), f"'{k}' (mapped by you)"; used.add(k)
    # unmatched export meshes: same-name vanilla mesh (largest one if several)
    for k in exp:
        if k in used:
            continue
        name = base_name(k)
        cands = [u for g, info in van.groups.items() for u in info["units"]
                 if van.by_label[u].name == name and ua.get(u) != "replace"]
        if not cands:
            plan.errors.append(f"'{k}' matches no vanilla mesh and no vanilla mesh is called '{name}' - "
                               f"pick its target in the mapping column")
            continue
        u = max(cands, key=lambda c: van.by_label[c].vertex_count)
        ua[u], us[u] = "replace", (k, None); used.add(k)
        frac = best[u][1] if best[u][0] == k else 0.0
        if name.startswith("skin_"):
            why[u] = f"new mesh '{k}' (by name)"
        else:
            why[u] = f"rebuilt from your '{k}' ({frac:.0%} of its vanilla vertices still in place)"
            plan.warnings.append(f"{name} doesn't match vanilla, so it's rebuilt from your mesh instead of kept - "
                                 f"fine if you edited it on purpose")
    pinned = {van.group_by_key(key) for key in keep_vanilla} - {None}
    for g, info in van.groups.items():
        units = info["units"]
        if not units:
            plan.action[g], plan.reason[g] = "remove", "no LOD0"; continue
        if g in pinned:
            for u in units:
                if ua[u] == "remove":
                    ua[u], why[u] = "keep", "kept vanilla (by you)"
                    us.pop(u, None)
        acts = {ua[u] for u in units}
        if acts == {"keep"}:
            plan.action[g] = "keep"
        elif acts == {"remove"}:
            plan.action[g] = "remove"
        else:
            plan.action[g] = "replace"
            if len(units) > 1 and "remove" in acts:
                gone = [van.by_label[u].name for u in units if ua[u] == "remove"]
                plan.warnings.append(f"{info['display']}: {', '.join(gone)} will be removed, the rest of the piece stays")
        if len(units) == 1:
            plan.reason[g] = why[units[0]]
            if plan.action[g] == "replace":
                plan.source[g] = us[units[0]]
        else:
            plan.reason[g] = " | ".join(f"{van.by_label[u].name}: {why[u]}" for u in units)
    return plan


def replaced_units(van, plan):
    """[(group, unit label, export name, vanilla label or None)] for every LOD0 mesh that gets new data."""
    out = []
    for g, info in van.groups.items():
        if plan.action.get(g) != "replace":
            continue
        for u in info["units"]:
            if plan.unit_action.get(u) == "replace":
                k, vl = plan.unit_source[u]
                out.append((g, u, k, vl))
    return out


# ------------------------------------------------------------------------------------------ build

def _encode(sem, fmt, d, n):
    if sem == "POSITION0" and fmt == 0x10:
        return d["P"].astype(np.float32).view(np.uint8).reshape(n, 12)
    if sem in ("NORMAL0", "TANGENT0") and fmt == 0xE:
        v = d["N"] if sem == "NORMAL0" else d["T"]
        w = np.zeros((n, 1)) if sem == "NORMAL0" else d["Tw"][:, None]
        return np.clip(np.round(np.hstack([v, w]) * 127), -127, 127).astype(np.int8).view(np.uint8)
    if sem in ("TEXCOORD0", "TEXCOORD1"):
        uv = d["U0"] if sem == "TEXCOORD0" else d["U1game"]
        if fmt == 0x15: return uv.astype(np.float32).view(np.uint8).reshape(n, 8)
        if fmt == 0x1A: return uv.astype(np.float16).view(np.uint8).reshape(n, 4)
        if fmt == 0x1B: return np.round(np.clip(uv, 0, 1) * 65535).astype(np.uint16).view(np.uint8).reshape(n, 4)
    if sem in ("BLENDINDICES0", "BLENDINDICES1") and fmt == 0x8:
        k = 0 if sem.endswith("0") else 4
        return d["Jq"][:, k:k + 4].astype(np.uint16).view(np.uint8).reshape(n, 8)
    if sem in ("BLENDWEIGHT0", "BLENDWEIGHT1") and fmt == 0xC:
        k = 0 if sem.endswith("0") else 4
        return d["Wq"][:, k:k + 4]
    if sem in ("NORMAL4FACTORS0", "NORMAL2FACTORS0"):
        return np.zeros((n, SIZE[fmt]), np.uint8)
    raise FskError(f"no encoder for {sem} format {fmt:#x}")


def _pack_streams(target, d, src, copy_set):
    n = len(d["P"]); out = []
    for s in target.streams:
        buf = np.zeros((n, s["stride"]), np.uint8)
        for off, sem, fmt in s["elements"]:
            val = _encode(sem, fmt, d, n)
            if src is not None and sem in copy_set and sem in src[1]:
                ssi, soff, sfmt = src[1][sem]
                if sfmt == fmt:
                    pick = src[3] if sem == "NORMAL4FACTORS0" else src[2]
                    m = pick >= 0
                    val = val.copy(); val[m] = src[0][ssi][pick[m], soff:soff + SIZE[fmt]]
            buf[:, off:off + SIZE[fmt]] = val
        out.append(buf.tobytes())
    return out


def untile(uv, I, eps=1e-6):
    """Undo the importer's tile move. Game UVs stacked vertically (v in [k, k+1)) arrive in Blender side by side
    (u + k, v - k), like UDIM 1001/1002. Move them back: u in [k, k+1) -> (u - k, v + k).
    A vertex sitting exactly on u = 1.0 is ambiguous (right edge of tile 0, or left edge of tile 1): it follows
    the other corners of its triangles."""
    uv = np.array(uv, np.float64)
    k = np.where(uv[:, 0] > 1.0 + eps, np.floor(uv[:, 0] - eps), 0.0)
    edge = (k == 0) & (np.abs(uv[:, 0] - np.round(uv[:, 0])) <= eps) & (uv[:, 0] >= 1.0 - eps)
    if edge.any() and (k > 0).any():
        T = np.asarray(I).reshape(-1, 3)
        tk = k[T].max(1)                                   # tile of each triangle (its highest corner)
        vk = np.zeros(len(uv))
        np.maximum.at(vk, T.ravel(), np.repeat(tk, 3))
        sel = edge & (vk > 0)
        k[sel] = vk[sel]
    uv[:, 0] -= k
    uv[:, 1] += k
    return uv


def _prepare(van, d, ekey):
    missing = sorted({d["joints"][j] for j in np.unique(d["J"][d["W"] > 0])} - set(van.bone_index))
    if missing:
        raise FskError(f"'{ekey}' is weighted to bones this model doesn't have: {missing[:10]}")
    remap = np.array([van.bone_index.get(nm, 0) for nm in d["joints"]], np.int64)
    Jq, Wq = quantize_weights(remap[d["J"]], d["W"])
    I_game = d["I"].reshape(-1, 3)[:, [0, 2, 1]].ravel()
    U0 = untile(d["U0"], d["I"])
    N = d["N"] / np.maximum(np.linalg.norm(d["N"], axis=1, keepdims=True), 1e-12)
    U1g = d["U1"].copy(); hi = U1g[:, 0] >= 1.0
    U1g[hi, 0] -= 1.0; U1g[hi, 1] = 1.0
    return dict(P=d["P"], N=N, U0=U0, U1game=U1g, Jq=Jq, Wq=Wq, I=I_game, ekey=ekey, src=None)


def _game_match(van, d, vlabel, log, gname):
    """Map export vertices onto the vanilla mesh they were edited from (copy the game's own data)."""
    vme = van.by_label[vlabel]
    rows, el, vpos, vuv = van.rows(vme)
    dist, cand = PointGrid(vpos, TOL).within(d["P"], k=8)
    match = np.full(len(d["P"]), -1, np.int64)
    for c in range(cand.shape[1]):
        ok = np.isfinite(dist[:, c]) & (match < 0)
        if vuv is not None:
            ok &= np.abs(vuv[np.where(cand[:, c] >= 0, cand[:, c], 0)] - d["U0"]).max(1) < 2e-3
        match[ok] = cand[ok, c]
    loose = (match < 0) & np.isfinite(dist[:, 0])
    match[loose] = cand[loose, 0]
    # vanilla position ids: coincident vanilla vertices (within TOL) share one id -> robust to float noise
    vgrid = PointGrid(vpos, TOL)
    _, vn = vgrid.within(vpos)
    rep = np.where(vn >= 0, vn, np.iinfo(np.int64).max).min(1)
    _, en = vgrid.nearest_within(d["P"])
    erep = np.where(en >= 0, rep[np.where(en >= 0, en, 0)], -1)
    if vme.face_index_count == vme.vertex_count:
        vI = np.arange(len(vpos)).reshape(-1, 3)
    else:
        vI = np.frombuffer(van.gpubin, np.uint32 if vme.face_index_type == 1 else np.uint16, vme.face_index_count,
                           vme.face_index_offset).astype(np.int64).reshape(-1, 3)
    vtri = {}
    for t in vI.tolist():
        vtri.setdefault(tuple(sorted(rep[c] for c in t)), t)
    corner = np.full(len(d["P"]), -1, np.int64); conflicts = 0
    for t in d["I"].reshape(-1, 3).tolist():
        r = [erep[c] for c in t]
        if min(r) < 0:
            continue
        vt = vtri.get(tuple(sorted(r)))
        if vt is None:
            continue
        for c, rc in zip(t, r):
            vc = next(x for x in vt if rep[x] == rc)
            if corner[c] < 0: corner[c] = vc
            elif corner[c] != vc: conflicts += 1
    match = np.where(corner >= 0, corner, match)
    collar = np.nonzero(vpos[:, 1] < COLLAR_Y)[0]
    f4 = corner.copy(); need = f4 < 0
    if need.any() and len(collar):
        _, nn_ = nearest(vpos[collar], d["P"][need]); f4[need] = collar[nn_]
    log.append(f"{gname}: {int((corner >= 0).sum())} corners mapped exactly through identical triangles "
               f"({conflicts} shared-vertex conflicts), {int(need.sum())} new corners take the old collar's values")
    log.append(f"{gname}: {int((match >= 0).sum())} of {len(match)} vertices keep the game's own data, "
               f"{int((match < 0).sum())} are new")
    return (rows, el, match, f4)


def _concat(parts):
    out, base = {}, 0
    for key in ("P", "N", "U0", "U1game", "Jq", "Wq", "T"):
        out[key] = np.vstack([p[key] for p in parts])
    out["Tw"] = np.concatenate([p["Tw"] for p in parts])
    idx = []
    for p in parts:
        idx.append(p["I"] + base); base += len(p["P"])
    out["I"] = np.concatenate(idx)
    out["src"] = None
    return out


def _bbox_overlap(A, B, pad=1e-3):
    return bool(np.all(A.min(0) - pad <= B.max(0)) and np.all(B.min(0) - pad <= A.max(0)))


def build(van, plan, exp, game_data=True, my_weights=False, variants=None):
    """exp: {export name: mesh dict} incl. LOD / VEM variants.
    game_data: copy vanilla per-vertex data onto unchanged vertices of edited meshes (the face rig).
    my_weights: ...but keep the exported bone weights instead of the game's.
    variants: {export name: {"lod1": name, ..., "vem": name}} export meshes feeding the LODs / VEM copy.
    Returns (model bytes, gpubin bytes, log lines)."""
    if plan.errors:
        raise FskError("plan has errors:\n" + "\n".join(plan.errors))
    log = []
    variants = variants or {}

    def feed_name(k, level):
        if level == "lod0":
            return k
        v = variants.get(k, {}).get(level)
        if v and v in exp:
            return v
        conv = f"{k}{VEM_SUFFIX}" if level == "vem" else f"{k}{LOD_SUFFIX}{level[3:]}"
        return conv if conv in exp else k

    action_of, feed = {}, {}                      # label -> keep/replace/remove ; label -> [(export name, level)]
    for g, info in van.groups.items():
        act = plan.action.get(g, "remove")
        for label in info["labels"]:
            action_of[label] = act
        if act != "replace":
            continue
        for label in info["labels"]:
            level = "vem" if label in info["vems"] else f"lod{info['level_of'][label]}"
            tr = info["track_of"][label]
            if tr is not None:
                ua = plan.unit_action.get(tr, "remove")
                action_of[label] = ua
                if ua == "replace":
                    feed[label] = [(feed_name(plan.unit_source[tr][0], level), level)]
            else:                                 # merged mesh (e.g. VEM of both shoes): rebuild from every unit
                parts = [u for u in info["units"] if plan.unit_action.get(u) != "remove"
                         and plan.unit_source.get(u, (None,))[0] in exp]
                if not parts:
                    action_of[label] = "remove"
                else:
                    action_of[label] = "replace"
                    feed[label] = [(feed_name(plan.unit_source[u][0], level), level) for u in parts]
    prepared = {}
    for parts in feed.values():
        for ename, _ in parts:
            if ename not in prepared:
                if ename not in exp:
                    raise FskError(f"export mesh '{ename}' missing from the export")
                prepared[ename] = _prepare(van, exp[ename], ename)

    # seam: shared vertices of meshes on the same level get one averaged normal
    done = set()
    levels = collections.defaultdict(set)
    for parts in feed.values():
        for ename, level in parts:
            levels[level].add(ename)
    for level in sorted(levels):
        names = sorted(levels[level])
        for i in range(len(names)):
            for k in range(i + 1, len(names)):
                pair = frozenset((names[i], names[k]))
                if pair in done:
                    continue
                done.add(pair)
                A, B = prepared[names[i]], prepared[names[k]]
                if not _bbox_overlap(A["P"], B["P"]):
                    continue
                dd, nn = PointGrid(B["P"], TOL).nearest_within(A["P"])
                s = np.nonzero(np.isfinite(dd))[0]
                if len(s):
                    avg = A["N"][s] + B["N"][nn[s]]
                    avg /= np.maximum(np.linalg.norm(avg, axis=1, keepdims=True), 1e-12)
                    A["N"][s] = avg; B["N"][nn[s]] = avg
                    same_w = bool(np.array_equal(A["Wq"][s], B["Wq"][nn[s]]) and np.array_equal(A["Jq"][s], B["Jq"][nn[s]]))
                    log.append(f"seam {names[i]} <-> {names[k]} ({level}): {len(s)} shared vertices, "
                               f"one averaged normal | weights identical: {same_w}")
    for ename, d in prepared.items():
        d["T"], d["Tw"] = compute_tangents(d["P"], d["N"], d["U0"], d["I"].reshape(-1, 3)[:, [0, 2, 1]].ravel())
    if game_data:
        for g, u, k, vlabel in replaced_units(van, plan):
            if vlabel and k in prepared:
                prepared[k]["src"] = _game_match(van, prepared[k], vlabel, log, van.by_label[vlabel].name)
    copy_set = COPY_FROM_GAME - (WEIGHT_SEMANTICS if my_weights else set())

    replace = {}
    for label, me in van.meshes:
        if action_of[label] != "replace":
            continue
        parts = feed[label]
        d = prepared[parts[0][0]] if len(parts) == 1 else _concat([prepared[n] for n, _ in parts])
        streams = _pack_streams(me, d, d["src"], copy_set)
        replace[label] = pack_geometry(streams, len(d["P"]), d["I"], d["P"], me.is_oriented_bb)
    new_model, new_gpubin = van.model.rebuild(van.gpubin, remove=lambda l, me: action_of[l] == "remove", replace=replace)
    Model(new_model)                                     # must re-parse
    c = collections.Counter(action_of.values())
    log.append(f"{c['keep']} meshes kept, {c['replace']} replaced, {c['remove']} removed | "
               f"gpubin {len(van.gpubin) / 1e6:.0f} MB -> {len(new_gpubin) / 1e6:.0f} MB")
    return new_model, new_gpubin, log
