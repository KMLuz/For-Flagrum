import bpy
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty,
                       StringProperty)
from bpy.types import AddonPreferences, PropertyGroup

from . import state

MASTER_BODY_URI = "data://asset/character/hu/hu000/model_400/materials/hu000_400_body_skin_mt.gmtl"


class FSK_Preferences(AddonPreferences):
    bl_idname = state.ADDON

    data_root: StringProperty(name="Game data folder", subtype='DIR_PATH',
                              description="Extracted game data: the folder that contains 'asset' (e.g. F:\\Mods\\Forspoken\\data)")
    character: StringProperty(name="Character", default="hu/hu000",
                              description="Character folder under asset/character (Frey is hu/hu000)")
    output_dir: StringProperty(name="Output folder", subtype='DIR_PATH',
                               description="Builds are written to <output folder>/<outfit>/")

    def draw(self, context):
        col = self.layout.column()
        col.prop(self, "data_root")
        col.prop(self, "character")
        col.prop(self, "output_dir")


class FSK_StrItem(PropertyGroup):
    value: StringProperty()


class FSK_Mapping(PropertyGroup):
    obj: StringProperty()
    target: StringProperty()
    label: StringProperty()


class FSK_Outfit(PropertyGroup):
    # name (built in) = outfit stem, e.g. hu000_100
    build_name: StringProperty()
    face_o: PointerProperty(type=bpy.types.Image)
    keep: CollectionProperty(type=FSK_StrItem)
    mappings: CollectionProperty(type=FSK_Mapping)


class FSK_PlanRow(PropertyGroup):
    key: StringProperty()
    piece: StringProperty()
    material: StringProperty()
    action: StringProperty()
    reason: StringProperty()
    lods: IntProperty()


def _mesh_poll(self, obj):
    return obj.type == 'MESH'


def _on_outfit(self, context):
    self.rows.clear()
    self.plan_info = ""
    o = state.outfit_settings(self, self.outfit, create=False)
    self["build_name"] = o.build_name if o else ""        # load this outfit's name without re-triggering save
    self.face_o = o.face_o if o else None                 # face _o differs per outfit (beanie vs hair down)


def _on_face_o(self, context):
    if self.outfit and self.outfit != "NONE":
        o = state.outfit_settings(self, self.outfit)
        if o.face_o != self.face_o:
            o.face_o = self.face_o


def _on_hair_thickness(self, context):
    from . import hair
    hair.set_thickness(self.hair_thickness)


def _on_build_name(self, context):
    if self.outfit and self.outfit != "NONE":
        state.outfit_settings(self, self.outfit).build_name = self.build_name


class FSK_Settings(PropertyGroup):
    outfit: EnumProperty(name="Outfit", items=state.outfit_items, update=_on_outfit,
                         description="Vanilla outfit model the build starts from")
    outfits: CollectionProperty(type=FSK_Outfit)
    build_name: StringProperty(name="Build name", update=_on_build_name,
                               description="Name of this build / variant (output folder and Flagrum mod name). "
                                           "Empty = the outfit, e.g. hu000_100. Remembered per outfit")
    rows: CollectionProperty(type=FSK_PlanRow)
    plan_info: StringProperty()
    plan_errors: StringProperty()

    head_object: PointerProperty(name="Head", type=bpy.types.Object, poll=_mesh_poll,
                                 description="Your head mesh (replaces skin_face). Its face textures follow the outfit's face material")
    body_object: PointerProperty(name="Body", type=bpy.types.Object, poll=_mesh_poll,
                                 description="Your body mesh. Its vanilla piece gets the body material swap")

    game_data: BoolProperty(name="Keep game data on unchanged head triangles", default=True,
                            description="Unchanged head vertices keep the game's normals, wrinkle factors and second UV "
                                        "(this is what keeps the face rig intact)")
    my_weights: BoolProperty(name="Use my weights anyway", default=False,
                             description="Keep your painted bone weights on unchanged head vertices instead of the game's")

    lods: BoolProperty(name="Auto LODs", default=True,
                       description="Decimate replaced meshes to the vanilla LOD proportions")
    lod_detail: FloatProperty(name="LOD detail", default=1.0, min=0.1, max=4.0,
                              description="Multiplier on the vanilla LOD triangle ratios (2 = twice as detailed)")
    seam_lock: IntProperty(name="Lock seam up to LOD", default=3, min=0, max=6,
                           description="Head/body seam vertices are never decimated on LODs up to this one")
    vem: BoolProperty(name="Low-poly VEM copy", default=True,
                      description="Decimate the VEM copy to the vanilla proportion (otherwise it gets the full mesh)")

    body_material: BoolProperty(name="Body uses the 400 skin material", default=True,
                                description="Write a copy of the master body material under the outfit's body material name")
    master_uri: StringProperty(name="Master", default=MASTER_BODY_URI)
    mat_emissive: FloatProperty(name="Emissive", default=0.0, min=0.0)
    mat_rough0: FloatProperty(name="Roughness 0", default=1.1, min=0.0)
    mat_rough1: FloatProperty(name="Roughness 1", default=0.7, min=0.0)
    mat_spec0: FloatProperty(name="Specular 0", default=2.0, min=0.0)
    mat_spec1: FloatProperty(name="Specular 1", default=1.0, min=0.0)

    textures: BoolProperty(name="Write textures", default=True)
    skin_separate: BoolProperty(name="Shared skin in its own build", default=True,
                                description="Textures and materials that every outfit uses (face skin from model_000, "
                                            "body skin from model_400, materials shared by several outfits) go to one "
                                            "separate build that is merged on every export, instead of into each outfit")
    skin_name: StringProperty(name="Skin build", default="Frey_Skin",
                              description="Name of the shared skin build (its folder in the output folder)")
    face_b: PointerProperty(type=bpy.types.Image, name="Face _b")
    face_n: PointerProperty(type=bpy.types.Image, name="Face _n")
    face_r: PointerProperty(type=bpy.types.Image, name="Face _r")
    face_s: PointerProperty(type=bpy.types.Image, name="Face _s")
    face_o: PointerProperty(type=bpy.types.Image, name="Face _o", update=_on_face_o,
                            description="Remembered per outfit - each outfit's hair/hat shades the face differently")
    body_b: PointerProperty(type=bpy.types.Image, name="Body _b")
    body_n: PointerProperty(type=bpy.types.Image, name="Body _n")
    body_r: PointerProperty(type=bpy.types.Image, name="Body _r")
    body_s: PointerProperty(type=bpy.types.Image, name="Body _s")
    body_o: PointerProperty(type=bpy.types.Image, name="Body _o")

    hair_file: EnumProperty(name="Hair", items=state.hair_items,
                            description="Hair file to show. 'Match the outfit' uses the hair named after the outfit")
    hair_thickness: FloatProperty(name="Strand thickness (mm)", default=1.5, min=0.1, max=10.0,
                                  update=_on_hair_thickness,
                                  description="How thick the preview strands are drawn (the game draws more, finer hairs)")

    show_plan: BoolProperty(default=True)
    show_options: BoolProperty(default=False)
    show_material: BoolProperty(default=False)
    show_textures: BoolProperty(default=False)


classes = (FSK_Preferences, FSK_StrItem, FSK_Mapping, FSK_Outfit, FSK_PlanRow, FSK_Settings)
