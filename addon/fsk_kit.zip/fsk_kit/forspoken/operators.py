import os
import shutil
import tempfile
import time
import traceback

import bpy
from bpy.props import EnumProperty, StringProperty
from bpy.types import Operator

from ..core import material as M
from ..core.build import base_name, build, make_plan, read_glb_meshes
from ..core.check import run_check
from ..core.glb import FskError, Glb
from . import lods as L
from . import state as S
from . import textures as T

ICON = {"keep": 'CHECKMARK', "replace": 'FILE_REFRESH', "remove": 'X'}


def _settings(context):
    return context.scene.fsk


def _auto_objects(settings, van, plan, objs):
    """Fill head/body pointers from the plan if they are empty."""
    by_name = {o.name: o for o in objs}
    for g, (ename, vlabel) in plan.source.items():
        if plan.action.get(g) != "replace" or ename not in by_name:
            continue
        piece = van.groups[g]["name"]
        if piece == "skin_face" and settings.head_object is None:
            settings.head_object = by_name[ename]
        elif piece.startswith("skin_") and piece != "skin_face" and vlabel is None and settings.body_object is None:
            settings.body_object = by_name[ename]


def _piece_of(plan, van, obj):
    if obj is None:
        return None
    for g, (ename, _) in plan.source.items():
        if ename == obj.name and plan.action.get(g) == "replace":
            return g
    return None


def _material_info(settings, van, plan):
    """(body target material uri, face material slots, body slots, warnings)."""
    warns = []
    root = S.data_root()
    body_g = _piece_of(plan, van, settings.body_object)
    face_g = _piece_of(plan, van, settings.head_object)
    body_target = van.groups[body_g]["material"] if body_g else None
    if body_target:
        sharing = [van.groups[g]["display"] for g, info in van.groups.items()
                   if g != body_g and info["material"] == body_target and plan.action.get(g) != "remove"]
        if sharing:
            warns.append(f"body material {body_target.split('/')[-1]} is also used by kept piece(s): "
                         f"{', '.join(sorted(set(sharing)))} - they will get the skin material too")
    face_slots, body_slots = {}, {}
    if face_g:
        p = M.uri_to_path(root, van.groups[face_g]["material"])
        if os.path.exists(p):
            face_slots = M.texture_slots(M.read(p)[0])
        else:
            warns.append(f"face material not found in game data: {p}")
    p = M.uri_to_path(root, settings.master_uri)
    if os.path.exists(p):
        body_slots = M.texture_slots(M.read(p)[0])
    else:
        warns.append(f"master body material not found in game data: {p}")
    return body_target, face_slots, body_slots, warns


def _plan(context, settings, objs, positions=None):
    van = S.vanilla(settings.outfit)
    if positions is None:
        positions = {o.name: S.gltf_positions(o) for o in objs}
    plan = make_plan(van, positions, keep_vanilla=S.keep_set(settings, settings.outfit),
                     mapping=S.mapping_dict(settings, settings.outfit))
    return van, plan


def _fill_rows(settings, van, plan, extra_warnings=()):
    settings.rows.clear()
    order = {"replace": 0, "keep": 1, "remove": 2}
    for g in sorted(plan.action, key=lambda g: (order[plan.action[g]], van.groups[g]["name"])):
        r = settings.rows.add()
        r.key = van.key(g)
        r.piece = van.groups[g]["display"]
        r.material = g[1]
        r.action = plan.action[g]
        r.reason = plan.reason.get(g, "")
        r.lods = len(van.groups[g]["labels"])
    settings.plan_errors = "\n".join(plan.errors)
    settings.plan_info = "\n".join(list(plan.warnings) + list(extra_warnings))


class FSK_OT_refresh(Operator):
    """Compare the selected objects with the vanilla outfit and show what the build will do"""
    bl_idname = "fsk.refresh_plan"
    bl_label = "Refresh plan"

    def execute(self, context):
        settings = _settings(context)
        objs = S.selected_meshes(context)
        if not objs:
            self.report({'WARNING'}, "Select the meshes you want in the build")
            return {'CANCELLED'}
        try:
            van, plan = _plan(context, settings, objs)
            _auto_objects(settings, van, plan, objs)
            _, _, _, warns = _material_info(settings, van, plan)
            _fill_rows(settings, van, plan, warns)
        except FskError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}


class FSK_OT_toggle_keep(Operator):
    """Keep this vanilla piece even though it isn't selected"""
    bl_idname = "fsk.toggle_keep"
    bl_label = "Keep vanilla"
    key: StringProperty()

    def execute(self, context):
        settings = _settings(context)
        o = S.outfit_settings(settings, settings.outfit)
        idx = next((i for i, k in enumerate(o.keep) if k.value == self.key), None)
        if idx is None:
            o.keep.add().value = self.key
        else:
            o.keep.remove(idx)
        return bpy.ops.fsk.refresh_plan()


_target_items = []


def _targets(self, context):
    _target_items.clear()
    _target_items.append(("__auto__", "Automatic (geometry / name)", ""))
    try:
        van = S.vanilla(_settings(context).outfit)
        for g, info in van.groups.items():
            k = van.key(g)
            if len(info["units"]) == 1:
                _target_items.append((k, f"{info['display']}  [{g[1]}]", k))
            else:
                for u in info["units"]:
                    _target_items.append((f"{k}#{u}", f"{van.by_label[u].name}  (part of {info['display']})", k))
    except FskError:
        pass
    return _target_items


class FSK_OT_pick_target(Operator):
    """Choose which vanilla piece this object replaces"""
    bl_idname = "fsk.pick_target"
    bl_label = "Replaces"
    obj: StringProperty()
    target: EnumProperty(items=_targets)

    def execute(self, context):
        settings = _settings(context)
        o = S.outfit_settings(settings, settings.outfit)
        idx = next((i for i, m in enumerate(o.mappings) if m.obj == self.obj), None)
        if self.target == "__auto__":
            if idx is not None:
                o.mappings.remove(idx)
        else:
            m = o.mappings[idx] if idx is not None else o.mappings.add()
            m.obj = self.obj
            m.target = self.target
            m.label = next((t[1].split("  ")[0] for t in _target_items if t[0] == self.target), self.target)
        return bpy.ops.fsk.refresh_plan()


def _gltf_export(path, objs):
    prev_sel = [o for o in bpy.context.selected_objects]
    prev_active = bpy.context.view_layer.objects.active
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    for o in objs:
        o.hide_set(False)
        o.select_set(True)
    try:
        bpy.ops.export_scene.gltf(
            filepath=path, export_format='GLB', use_selection=True, export_apply=True,
            export_texcoords=True, export_normals=True, export_tangents=False, export_materials='NONE',
            export_vertex_color='NONE', export_skins=True, export_all_influences=True, export_def_bones=False,
            export_animations=False, export_morph=False, export_yup=True, export_cameras=False,
            export_lights=False, export_draco_mesh_compression_enable=False, export_extras=False)
    finally:
        for o in bpy.context.view_layer.objects:
            o.select_set(False)
        for o in prev_sel:
            if o.name in bpy.context.view_layer.objects:
                o.select_set(True)
        bpy.context.view_layer.objects.active = prev_active


def _read_entries(path):
    out = {}
    if os.path.exists(path):
        uri = None
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if line.startswith("Replace:"):
                uri = line[len("Replace:"):].strip()
            elif line.startswith("With:") and uri:
                out[uri] = line[len("With:"):].strip(); uri = None
    return out


def _write_entries(path, header, entries):
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"# {header} - written by FSK\n\n")
        for uri, p in entries.items():
            f.write(f"Replace: {uri}\nWith:    {p}\n\n")


def _skin_name(settings):
    return S.clean_name(settings.skin_name) or "Frey_Skin"


def _is_outfit_file(settings, van, uri):
    """Files inside the outfit's own folder belong to the outfit build; everything else is shared skin."""
    if not settings.skin_separate:
        return True
    return str(uri).startswith(van.ref_uri().rsplit("/", 1)[0] + "/")


def _write_extras(settings, van, body_target, face_slots, body_slots, out, skin_out, log):
    """Body material copy + textures. Returns (outfit entries, skin entries) as ordered dicts."""
    ent = {True: {}, False: {}}
    where = lambda uri: (_is_outfit_file(settings, van, uri), out if _is_outfit_file(settings, van, uri) else skin_out)
    if settings.body_material and body_target:
        src = M.uri_to_path(S.data_root(), settings.master_uri)
        if not os.path.exists(src):
            raise FskError(f"master body material not found: {src}")
        data = M.set_parameters(open(src, "rb").read(), {
            "EmissiveIntensity0": settings.mat_emissive,
            "RoughnessIntensity0": settings.mat_rough0, "RoughnessIntensity1": settings.mat_rough1,
            "SpecularIntensity0": settings.mat_spec0, "SpecularIntensity1": settings.mat_spec1})
        own, base = where(body_target)
        mdir = os.path.join(base, "materials")
        os.makedirs(mdir, exist_ok=True)
        mpath = os.path.join(mdir, body_target.split("/")[-1] + ".gfxbin")
        with open(mpath, "wb") as f:
            f.write(data)
        ent[own][body_target] = mpath
        log.append(f"body material: {body_target.split('/')[-1]} <- copy of {settings.master_uri.split('/')[-1]}"
                   f"{'' if own else '  [shared -> skin build]'}")
    if settings.textures:
        for label, img, uri in T.plan_textures(settings, face_slots, body_slots if settings.body_material else {}):
            own, base = where(uri)
            stem = os.path.splitext(uri.split("/")[-1])[0]
            files = T.write_sizes(img, os.path.join(base, "textures"), stem, label)
            for e_uri, variant in zip(M.texture_entry_uris(uri), ("", "_$m1", "_$h")):
                ent[own][e_uri] = files[variant]
            log.append(f"texture {label}: {img.name} -> {stem}{'' if own else '  [skin build]'}")
    return ent[True], ent[False]


def _publish_skin(settings, skin_entries, skin_out, log):
    if not skin_entries:
        return 0
    path = os.path.join(skin_out, "entries.txt")
    merged = _read_entries(path)
    merged.update(skin_entries)
    _write_entries(path, f"Flagrum Replace entries for {_skin_name(settings)} (shared skin, merged)", merged)
    with open(os.path.join(skin_out, "build_log.txt"), "a", encoding="utf-8") as f:
        f.write(time.strftime("%Y-%m-%d %H:%M  ") + f"{len(skin_entries)} entries updated\n")
    return len(merged)


class FSK_OT_export(Operator):
    """Build the outfit from the selected objects and write everything Flagrum needs"""
    bl_idname = "fsk.export"
    bl_label = "Export to Flagrum"

    def execute(self, context):
        settings = _settings(context)
        objs = S.selected_meshes(context)
        if not objs:
            self.report({'WARNING'}, "Select the meshes you want in the build")
            return {'CANCELLED'}
        created, tmp = [], tempfile.mkdtemp(prefix="fsk_")
        t0 = time.time()
        log = []
        try:
            van, plan = _plan(context, settings, objs)
            _auto_objects(settings, van, plan, objs)
            if plan.errors:
                _fill_rows(settings, van, plan)
                raise FskError("Fix the plan first:\n" + "\n".join(plan.errors))
            body_target, face_slots, body_slots, warns = _material_info(settings, van, plan)
            if settings.textures:
                for label, img, uri in T.plan_textures(settings, face_slots, body_slots if settings.body_material else {}):
                    T.source_path(img, label)          # raises a clear error for multi-tile sets / missing files
            variants = {}
            if settings.lods:
                created, variants, lod_log = L.make_lods(van, plan, objs, settings.lod_detail,
                                                         settings.seam_lock, settings.vem)
                log += lod_log
            glb_path = os.path.join(tmp, "export.glb")
            _gltf_export(glb_path, objs + created + S.armatures_of(objs))
            exp = read_glb_meshes(Glb(glb_path))
            missing = [o.name for o in objs if o.name not in exp]
            if missing:
                raise FskError(f"glTF export dropped: {', '.join(missing)} (are they skinned to the armature?)")
            plan = make_plan(van, {k: v["P"] for k, v in exp.items()},
                             keep_vanilla=S.keep_set(settings, settings.outfit),
                             mapping=S.mapping_dict(settings, settings.outfit))
            model_b, gpubin_b, blog = build(van, plan, exp, game_data=settings.game_data,
                                            my_weights=settings.my_weights, variants=variants)
            log += blog
            # validate in temp, then publish
            chk = os.path.join(tmp, "check")
            os.makedirs(chk)
            with open(os.path.join(chk, f"{van.stem}.gmdl.gfxbin"), "wb") as f:
                f.write(model_b)
            with open(os.path.join(chk, f"{van.stem}_0.gpubin"), "wb") as f:
                f.write(gpubin_b)
            ok, clines = run_check(os.path.join(chk, f"{van.stem}.gmdl.gfxbin"), van.path)
            log += clines
            if not ok:
                raise FskError("Validation failed - nothing written:\n" + "\n".join(clines))

            name = S.build_name(settings, van.stem)
            skin = _skin_name(settings)
            if settings.skin_separate and name == skin:
                raise FskError(f"The build can't have the same name as the skin build ('{skin}')")
            out = S.output_dir(name)
            skin_out = S.output_dir(skin)
            os.makedirs(out, exist_ok=True)
            mp = os.path.join(out, f"{van.stem}.gmdl.gfxbin")
            gp = os.path.join(out, f"{van.stem}_0.gpubin")
            shutil.copyfile(os.path.join(chk, f"{van.stem}.gmdl.gfxbin"), mp)
            shutil.copyfile(os.path.join(chk, f"{van.stem}_0.gpubin"), gp)
            entries = {van.ref_uri(): mp, van.gpubin_uri(): gp}
            own, shared = _write_extras(settings, van, body_target, face_slots, body_slots, out, skin_out, log)
            entries.update(own)
            _write_entries(os.path.join(out, "entries.txt"), f"Flagrum Replace entries for {name} (outfit {van.stem})", entries)
            skin_total = _publish_skin(settings, shared, skin_out, log)
            with open(os.path.join(out, "build_log.txt"), "w", encoding="utf-8") as f:
                f.write("\n".join(log + [f"warning: {w}" for w in warns]))
            _fill_rows(settings, van, plan, warns)
            msg = f"'{name}': {len(entries)} Flagrum entries"
            if shared:
                msg += f" | '{skin}': {len(shared)} updated ({skin_total} total)"
            self.report({'INFO'}, f"{msg} ({time.time() - t0:.0f}s)")
        except FskError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        except Exception as e:
            traceback.print_exc()
            self.report({'ERROR'}, f"Export failed: {e!r} (details in the system console)")
            return {'CANCELLED'}
        finally:
            L.remove(created)
            shutil.rmtree(tmp, ignore_errors=True)
        return {'FINISHED'}


class FSK_OT_export_textures(Operator):
    """Write only the textures and the body material (no model build): shared skin goes to the skin build,
    the outfit's own files are merged into its build"""
    bl_idname = "fsk.export_textures"
    bl_label = "Export textures only"

    def execute(self, context):
        settings = _settings(context)
        objs = S.selected_meshes(context) or [o for o in (settings.head_object, settings.body_object) if o]
        if not objs:
            self.report({'WARNING'}, "Select your head and body (or set them in the panel)")
            return {'CANCELLED'}
        t0, log = time.time(), []
        try:
            van, plan = _plan(context, settings, objs)
            _auto_objects(settings, van, plan, objs)
            body_target, face_slots, body_slots, warns = _material_info(settings, van, plan)
            jobs = T.plan_textures(settings, face_slots, body_slots if settings.body_material else {}) if settings.textures else []
            for label, img, uri in jobs:
                T.source_path(img, label)
            name, skin = S.build_name(settings, van.stem), _skin_name(settings)
            if settings.skin_separate and name == skin:
                raise FskError(f"The build can't have the same name as the skin build ('{skin}')")
            out, skin_out = S.output_dir(name), S.output_dir(skin)
            own, shared = _write_extras(settings, van, body_target, face_slots, body_slots, out, skin_out, log)
            if own:
                path = os.path.join(out, "entries.txt")
                merged = _read_entries(path)
                merged.update(own)
                _write_entries(path, f"Flagrum Replace entries for {name} (outfit {van.stem})", merged)
            total = _publish_skin(settings, shared, skin_out, log)
            parts = []
            if shared:
                parts.append(f"'{skin}': {len(shared)} updated ({total} total)")
            if own:
                parts.append(f"'{name}': {len(own)} updated")
            self.report({'INFO'}, (" | ".join(parts) or "nothing to write - assign textures first")
                        + f" ({time.time() - t0:.0f}s)")
        except FskError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        except Exception as e:
            traceback.print_exc()
            self.report({'ERROR'}, f"Export failed: {e!r} (details in the system console)")
            return {'CANCELLED'}
        return {'FINISHED'}


class FSK_OT_open_output(Operator):
    """Open this outfit's output folder"""
    bl_idname = "fsk.open_output"
    bl_label = "Open output folder"

    def execute(self, context):
        try:
            st = _settings(context)
            p = S.output_dir(S.build_name(st, st.outfit))
        except FskError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        if not os.path.isdir(p):
            self.report({'WARNING'}, f"Nothing exported as '{os.path.basename(p)}' yet")
            return {'CANCELLED'}
        bpy.ops.wm.path_open(filepath=p)
        return {'FINISHED'}


# ------------------------------------------------------------------------------ cleanup

class FSK_OT_normalize_weights(Operator):
    """Limit every vertex to 8 bone influences and normalise (what the game supports)"""
    bl_idname = "fsk.normalize_weights"
    bl_label = "Limit to 8 + normalise"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        objs = S.selected_meshes(context)
        for o in objs:
            with context.temp_override(object=o, active_object=o, selected_objects=[o], selected_editable_objects=[o]):
                bpy.ops.object.vertex_group_limit_total(group_select_mode='BONE_DEFORM', limit=8)
                bpy.ops.object.vertex_group_normalize_all(group_select_mode='BONE_DEFORM', lock_active=False)
        self.report({'INFO'}, f"{len(objs)} object(s) limited to 8 influences and normalised")
        return {'FINISHED'}


class FSK_OT_remove_empty_groups(Operator):
    """Delete vertex groups that have no weights"""
    bl_idname = "fsk.remove_empty_groups"
    bl_label = "Remove empty vertex groups"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        total = 0
        for o in S.selected_meshes(context):
            used = set()
            for v in o.data.vertices:
                for g in v.groups:
                    if g.weight > 0:
                        used.add(g.group)
            for vg in [vg for vg in o.vertex_groups if vg.index not in used]:
                o.vertex_groups.remove(vg)
                total += 1
        self.report({'INFO'}, f"removed {total} empty vertex group(s)")
        return {'FINISHED'}


classes = (FSK_OT_refresh, FSK_OT_toggle_keep, FSK_OT_pick_target, FSK_OT_export, FSK_OT_export_textures,
           FSK_OT_open_output,
           FSK_OT_normalize_weights, FSK_OT_remove_empty_groups)
