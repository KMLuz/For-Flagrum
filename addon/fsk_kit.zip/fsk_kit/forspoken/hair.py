"""Hair preview: shows Forspoken strand hair (.gmdl_hair) in Blender as thin curves, one object per hair group.

Preview only. Hair isn't edited or exported, and the export ignores these objects (they aren't meshes).
"""
import os

import bpy
from bpy.props import BoolProperty, FloatProperty, StringProperty
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper

from ..core import hair as H
from . import state as S

PREVIEW_KEY = "fsk_hair_preview"
MATERIAL_NAME = "FSK Hair Preview"
HAIR_COLOR = (0.06, 0.035, 0.02, 1.0)
TIP_RADIUS = 0.35          # strands taper to this fraction of the thickness at the tip


def previews():
    return [c for c in bpy.data.collections if PREVIEW_KEY in c]


def remove_previews():
    for coll in previews():
        for obj in list(coll.objects):
            data = obj.data
            bpy.data.objects.remove(obj, do_unlink=True)
            if data is not None and data.users == 0:
                bpy.data.curves.remove(data)
        bpy.data.collections.remove(coll)


def set_thickness(thickness_mm):
    for coll in previews():
        for obj in coll.objects:
            if obj.type == 'CURVE':
                obj.data.bevel_depth = thickness_mm / 2000.0


def _material():
    mat = bpy.data.materials.get(MATERIAL_NAME)
    if mat is None:
        mat = bpy.data.materials.new(MATERIAL_NAME)
        mat.diffuse_color = HAIR_COLOR            # Solid view
        mat.roughness = 0.6
        if not getattr(mat, "use_nodes", True):    # Blender 5 always uses nodes and deprecates the setting
            mat.use_nodes = True
        bsdf = mat.node_tree.nodes.get("Principled BSDF") if mat.node_tree else None
        if bsdf is not None:                       # Material Preview / Rendered view
            bsdf.inputs["Base Color"].default_value = HAIR_COLOR
            bsdf.inputs["Roughness"].default_value = 0.6
    return mat


def build_preview(context, path, thickness_mm):
    """Create a collection with one curve object per full-detail hair group. Returns (collection, strand count)."""
    hair = H.read(path)
    groups = [g for g in hair["groups"] if H.is_full_detail(g)] or hair["groups"]
    stem = os.path.basename(path)
    if stem.lower().endswith(".gmdl_hair"):
        stem = stem[: -len(".gmdl_hair")]

    coll = bpy.data.collections.new(f"Hair preview ({stem})")
    coll[PREVIEW_KEY] = path
    context.scene.collection.children.link(coll)
    mat = _material()
    total = 0
    for g in groups:
        cu = bpy.data.curves.new(f"{stem} {g['name']}", 'CURVE')
        cu.dimensions = '3D'
        cu.bevel_depth = thickness_mm / 2000.0
        cu.bevel_resolution = 0
        cu.materials.append(mat)
        for strand in g["strands"]:
            n = len(strand)
            sp = cu.splines.new('POLY')
            sp.points.add(n - 1)
            co = []
            for x, y, z in strand:                 # game axes (Y up) -> Blender (Z up), as the model import does
                co += (x, -z, y, 1.0)
            sp.points.foreach_set("co", co)
            if n > 1:                              # the first point is the root
                sp.points.foreach_set("radius", [1.0 - (1.0 - TIP_RADIUS) * i / (n - 1) for i in range(n)])
        obj = bpy.data.objects.new(cu.name, cu)
        obj[PREVIEW_KEY] = True
        obj.hide_select = True                     # clicks go through to the head and body underneath
        coll.objects.link(obj)
        total += len(g["strands"])
    return coll, total


def _report_loaded(op, loaded):
    strands = sum(n for _, n in loaded)
    names = ", ".join(c.name for c, _ in loaded)
    op.report({'INFO'}, f"{names}: {strands} strands (hide it with the eye icon in the Outliner)")


class FSK_OT_show_hair(Operator):
    """Show the hair chosen in the list next to the model (preview only, it isn't exported)"""
    bl_idname = "fsk.show_hair"
    bl_label = "Show hair"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.fsk
        try:
            if s.hair_file == "AUTO":
                if not s.outfit or s.outfit == "NONE":
                    raise S.FskError("Pick an outfit first, or choose a hair file in the list")
                paths = S.hair_for_outfit(s.outfit)
                if not paths:
                    raise S.FskError(f"No hair file named after {s.outfit} in the game data folder. Export the "
                                     f"outfit's folder with ForFlagrum's Asset Explorer, or choose a hair file "
                                     f"in the list (or File > Import > Forspoken hair)")
            else:
                paths = [S.hair_path(s.hair_file)]
            remove_previews()
            loaded = [build_preview(context, p, s.hair_thickness) for p in paths]
        except S.FskError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        except OSError as e:
            self.report({'ERROR'}, f"Couldn't read the hair file: {e}")
            return {'CANCELLED'}
        _report_loaded(self, loaded)
        return {'FINISHED'}


class FSK_OT_remove_hair(Operator):
    """Remove the hair preview"""
    bl_idname = "fsk.remove_hair"
    bl_label = "Remove hair preview"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        remove_previews()
        return {'FINISHED'}


class FSK_OT_rescan_hair(Operator):
    """Look for hair files in the game data folder again"""
    bl_idname = "fsk.rescan_hair"
    bl_label = "Rescan hair files"

    def execute(self, context):
        n = len(S.scan_hair(force=True))
        self.report({'INFO'}, f"{n} hair file(s) found")
        return {'FINISHED'}


class FSK_OT_import_hair(Operator, ImportHelper):
    """Show a Forspoken hair file (.gmdl_hair) next to the model (preview only, it isn't exported)"""
    bl_idname = "fsk.import_hair"
    bl_label = "Import Forspoken Hair (.gmdl_hair)"
    bl_options = {'REGISTER', 'UNDO'}
    filename_ext = ".gmdl_hair"

    filter_glob: StringProperty(default="*.gmdl_hair", options={'HIDDEN'})
    replace: BoolProperty(name="Replace the current hair preview", default=True)
    thickness: FloatProperty(name="Strand thickness (mm)", default=1.5, min=0.1, max=10.0)

    def invoke(self, context, event):
        self.thickness = context.scene.fsk.hair_thickness
        return super().invoke(context, event)

    def execute(self, context):
        try:
            if self.replace:
                remove_previews()
            loaded = [build_preview(context, self.filepath, self.thickness)]
        except S.FskError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        except OSError as e:
            self.report({'ERROR'}, f"Couldn't read the hair file: {e}")
            return {'CANCELLED'}
        _report_loaded(self, loaded)
        return {'FINISHED'}


def menu_import_hair(self, context):
    self.layout.operator(FSK_OT_import_hair.bl_idname, text="Forspoken hair (.gmdl_hair)")


classes = (FSK_OT_show_hair, FSK_OT_remove_hair, FSK_OT_rescan_hair, FSK_OT_import_hair)
