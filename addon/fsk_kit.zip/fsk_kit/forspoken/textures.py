"""Write game-ready texture sets: <name>_$h (full), <name>_$m1 (half), <name> (quarter), PNG."""
import os
import struct

import bpy

from ..core import material as M
from ..core.glb import FskError

SUFFIX_OF_SLOT = M.CORE_SLOTS                     # slot -> _b/_n/_r/_s/_o


def png_size(path):
    """(w, h) from a PNG header without loading it, or None."""
    try:
        with open(path, "rb") as f:
            head = f.read(24)
        if head[:8] == b"\x89PNG\r\n\x1a\n":
            return struct.unpack(">II", head[16:24])
    except OSError:
        pass
    return None


def source_path(img, label=""):
    """(file to read, note). Blender shows any name with 1001..1099 in it as a UDIM tile: a single tile is just a
    file. If the assigned file is the base or _$m1 size and a bigger _$h file sits next to it, the _$h one is used."""
    if img.source == 'TILED':
        tiles = sorted(t.number for t in img.tiles)
        if len(tiles) != 1:
            raise FskError(f"{label}: '{img.name}' is a set of {len(tiles)} UDIM tiles ({', '.join(map(str, tiles))}). "
                           f"The game uses one image here - assign the game-ready file instead (body: the 4096 GameAtlas)")
        path = bpy.path.abspath(img.filepath_raw or img.filepath).replace("<UDIM>", str(tiles[0]))
    elif img.source == 'FILE' and img.filepath:
        path = bpy.path.abspath(img.filepath)
    else:
        return None, "generated / packed image"
    if not os.path.exists(path):
        raise FskError(f"{label}: file not found: {path}")
    stem, ext = os.path.splitext(path)
    big = stem[: -len("_$m1")] + "_$h" + ext if stem.endswith("_$m1") else (None if stem.endswith("_$h") else stem + "_$h" + ext)
    if big and os.path.exists(big):
        a, b = png_size(path), png_size(big)
        if a and b and b[0] > a[0]:
            return big, f"using the bigger {os.path.basename(big)} next to it"
    return path, ""


def resolve(img, label=""):
    """The single image to write from. Returns (image, temporary) - temporary images are removed by the caller."""
    path, _ = source_path(img, label)
    if path is None or (img.source == 'FILE' and os.path.normcase(path) == os.path.normcase(bpy.path.abspath(img.filepath))):
        return img, False
    single = bpy.data.images.load(path, check_existing=False)
    single.colorspace_settings.name = img.colorspace_settings.name
    return single, True


def write_sizes(img, out_dir, stem, label=""):
    """Save img three times. Returns {variant: path} with variants '', '_$m1', '_$h'."""
    if img is None:
        return {}
    img, temporary = resolve(img, label)
    try:
        return _write(img, out_dir, stem)
    finally:
        if temporary:
            bpy.data.images.remove(img)


def _write(img, out_dir, stem):
    if not img.has_data:
        img.reload()
    w, h = img.size
    if w == 0 or h == 0:
        raise RuntimeError(f"image '{img.name}' has no pixels (file missing?)")
    os.makedirs(out_dir, exist_ok=True)
    out = {}
    for variant, div in (("_$h", 1), ("_$m1", 2), ("", 4)):
        cp = img.copy()
        try:
            cp.scale(max(1, w // div), max(1, h // div))     # also forces a pixel buffer at full size
            path = os.path.join(out_dir, f"{stem}{variant}.png")
            cp.filepath_raw = path
            cp.file_format = 'PNG'
            cp.save()
            out[variant] = path
        finally:
            bpy.data.images.remove(cp)
    return out


def plan_textures(settings, face_slots, body_slots):
    """[(label, image, uri)] for every assigned image. *_slots are {slot: uri} from the materials."""
    jobs = []
    for role, slots in (("face", face_slots), ("body", body_slots)):
        if not slots:
            continue
        for slot, suf in SUFFIX_OF_SLOT.items():
            img = getattr(settings, f"{role}{suf}", None)
            uri = slots.get(slot)
            if img is not None and uri:
                jobs.append((f"{role} {suf}", img, uri))
    return jobs
