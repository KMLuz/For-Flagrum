"""Shared helpers for the Forspoken panel/operators: preferences, outfit discovery, caches."""
import glob
import os
import re

import bpy
import numpy as np

from ..core.build import Vanilla, base_name
from ..core.glb import FskError

ADDON = __package__.split(".")[0]
_vanilla_cache = {}
_outfit_items = []          # Blender needs enum item strings kept alive
_hair_items = []
_hair_cache = {}


def prefs():
    return bpy.context.preferences.addons[ADDON].preferences


def data_root():
    p = bpy.path.abspath(prefs().data_root).rstrip("\\/")
    if not p or not os.path.isdir(p):
        raise FskError("Set the game data folder in the add-on preferences (the folder that contains 'asset').")
    if os.path.basename(p) == "asset":           # accept the asset folder itself too
        p = os.path.dirname(p)
    return p


def character_dir():
    return os.path.join(data_root(), "asset", "character", *prefs().character.strip("/\\").split("/"))


def clean_name(name):
    """Folder-safe build name (Windows rules)."""
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", (name or "").strip()).rstrip(". ")
    return name


def build_name(settings, stem):
    """The build name for an outfit: what you typed, or the outfit itself (e.g. hu000_100)."""
    return clean_name(settings.build_name) or stem


def output_dir(name):
    root = bpy.path.abspath(prefs().output_dir)
    if not root:
        raise FskError("Set the output folder in the add-on preferences.")
    return os.path.join(root, name)


def scan_outfits():
    try:
        base = character_dir()
    except FskError:
        return []
    found = []
    for d in sorted(glob.glob(os.path.join(base, "model_*"))):
        for f in sorted(glob.glob(os.path.join(d, "*.gmdl.gfxbin"))):
            stem = os.path.basename(f)[: -len(".gmdl.gfxbin")]
            if os.path.exists(os.path.join(d, f"{stem}_0.gpubin")):
                found.append((stem, os.path.basename(d), f))
    return found


def outfit_items(self, context):
    _outfit_items.clear()
    for stem, folder, path in scan_outfits():
        _outfit_items.append((stem, f"{stem}  ({folder})", path))
    if not _outfit_items:
        _outfit_items.append(("NONE", "No outfits found - check preferences", ""))
    return _outfit_items


def scan_hair(force=False):
    """Hair files (.gmdl_hair) anywhere under the character folder, scanned once and cached."""
    try:
        base = character_dir()
    except FskError:
        return []
    if force or _hair_cache.get("root") != base:
        found = []
        for dirpath, _dirs, names in os.walk(base):
            found += [os.path.join(dirpath, n) for n in names if n.lower().endswith(".gmdl_hair")]
        _hair_cache.update(root=base, files=sorted(found, key=lambda p: os.path.basename(p).lower()))
    return _hair_cache["files"]


def _hair_id(path):
    return os.path.relpath(path, character_dir()).replace("\\", "/")


def hair_items(self, context):
    _hair_items.clear()
    _hair_items.append(("AUTO", "Match the outfit", "The hair file(s) named after the selected outfit"))
    for p in scan_hair():
        _hair_items.append((_hair_id(p), os.path.basename(p)[: -len(".gmdl_hair")], p))
    return _hair_items


def hair_path(hair_id):
    path = os.path.join(character_dir(), *hair_id.split("/"))
    if not os.path.isfile(path):
        raise FskError(f"hair file not found: {path} - press the rescan button")
    return path


def hair_for_outfit(stem):
    """Hair files named after the outfit (hu000_110 -> hu000_110_hair_head.gmdl_hair). Rescans once if none."""
    prefix = stem.lower() + "_"
    for force in (False, True):
        match = [p for p in scan_hair(force) if os.path.basename(p).lower().startswith(prefix)]
        if match:
            return match
    return []


def outfit_path(stem):
    for s, folder, path in scan_outfits():
        if s == stem:
            return path
    raise FskError(f"outfit '{stem}' not found under {character_dir()}")


def vanilla(stem):
    path = outfit_path(stem)
    key = (path, os.path.getmtime(path))
    v = _vanilla_cache.get(key)
    if v is None:
        _vanilla_cache.clear()
        v = _vanilla_cache[key] = Vanilla(path)
    return v


def outfit_settings(settings, stem, create=True):
    for o in settings.outfits:
        if o.name == stem:
            return o
    if not create:
        return None
    o = settings.outfits.add()
    o.name = stem
    return o


def gltf_positions(obj):
    """World-space vertex positions in glTF axes (Y up), from the mesh as it is in edit/object mode."""
    me = obj.data
    co = np.empty(len(me.vertices) * 3, np.float64)
    me.vertices.foreach_get("co", co)
    co = co.reshape(-1, 3)
    M = np.array(obj.matrix_world, np.float64)
    w = co @ M[:3, :3].T + M[:3, 3]
    return np.stack([w[:, 0], w[:, 2], -w[:, 1]], 1)


def selected_meshes(context):
    return [o for o in context.selected_objects if o.type == 'MESH' and "__fsk_" not in o.name]


def armatures_of(objs):
    out = []
    for o in objs:
        for m in o.modifiers:
            if m.type == 'ARMATURE' and m.object and m.object not in out:
                out.append(m.object)
        if o.parent and o.parent.type == 'ARMATURE' and o.parent not in out:
            out.append(o.parent)
    return out


def mapping_dict(settings, stem):
    o = outfit_settings(settings, stem, create=False)
    return {m.obj: m.target for m in o.mappings} if o else {}


def keep_set(settings, stem):
    o = outfit_settings(settings, stem, create=False)
    return {k.value for k in o.keep} if o else set()


__all__ = ["prefs", "data_root", "character_dir", "output_dir", "clean_name", "build_name", "scan_outfits", "outfit_items", "outfit_path",
           "scan_hair", "hair_items", "hair_path", "hair_for_outfit",
           "vanilla", "outfit_settings", "gltf_positions", "selected_meshes", "armatures_of", "mapping_dict",
           "keep_set", "base_name", "FskError"]
