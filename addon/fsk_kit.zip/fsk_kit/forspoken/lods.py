"""Auto LODs: temporary decimated copies of replaced meshes, sized to the vanilla LOD proportions."""
import bmesh
import bpy
import numpy as np

from ..core.build import TOL
from ..core.spatial import PointGrid
from .state import gltf_positions

GROUP = "fsk_decimate"
WELD = 1e-5


def _seam_mask(P, others):
    m = np.zeros(len(P), bool)
    for Q in others:
        if len(Q):
            d, _ = PointGrid(Q, TOL).nearest_within(P)
            m |= np.isfinite(d)
    return m


def _clear_custom_normals(obj):
    try:
        with bpy.context.temp_override(object=obj, active_object=obj, selected_objects=[obj]):
            bpy.ops.mesh.customdata_custom_splitnormals_clear()
    except Exception:
        pass


def _make_copy(obj, name, ratio, others, lock):
    dup = obj.copy()
    dup.data = obj.data.copy()
    dup.name = name
    for col in obj.users_collection:
        col.objects.link(dup)
    bm = bmesh.new()
    bm.from_mesh(dup.data)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=WELD)
    bm.to_mesh(dup.data)
    bm.free()
    _clear_custom_normals(dup)
    for p in dup.data.polygons:
        p.use_smooth = True
    vg = dup.vertex_groups.get(GROUP) or dup.vertex_groups.new(name=GROUP)
    n = len(dup.data.vertices)
    vg.add(list(range(n)), 1.0, 'REPLACE')
    if lock:
        seam = np.nonzero(_seam_mask(gltf_positions(dup), others))[0].tolist()
        if seam:
            vg.add(seam, 0.0, 'REPLACE')
    mod = dup.modifiers.new("fsk_decimate", 'DECIMATE')
    mod.decimate_type = 'COLLAPSE'
    mod.ratio = float(min(1.0, max(ratio, 1e-4)))
    mod.use_collapse_triangulate = True
    if lock:
        mod.vertex_group = GROUP
        mod.vertex_group_factor = 1000.0
    return dup


def make_lods(van, plan, objs, detail=1.0, seam_lock=3, vem=True):
    """Create decimated copies for every mesh that feeds a rebuilt LOD / VEM mesh.
    Returns (created objects, variants {export name: {level: object name}}, log lines)."""
    by_name = {o.name: o for o in objs}
    jobs = []                                         # (export name, piece display, {level: ratio})
    for g, info in van.groups.items():
        if plan.action.get(g) != "replace":
            continue
        units = info["units"]
        tot0 = sum(info["track_tris"][u]["lod0"] for u in units) or 1
        for u in units:
            ua = plan.unit_action.get(u)
            k = plan.unit_source.get(u, (None,))[0]
            if ua == "remove" or k not in by_name:
                continue
            levels = {}
            if ua == "replace":
                t0 = info["track_tris"][u]["lod0"] or 1
                levels.update({lv: t / t0 for lv, t in info["track_tris"][u].items() if lv != "lod0"})
            levels.update({lv: t / tot0 for lv, t in info["combined_tris"].items() if lv != "lod0"})
            if not vem:
                levels.pop("vem", None)
            if levels:
                jobs.append((k, van.by_label[u].name, levels))
    positions = {k: gltf_positions(by_name[k]) for k, _, _ in jobs}
    created, variants, log, cache = [], {}, [], {}
    for k, piece, levels in jobs:
        others = [P for n, P in positions.items() if n != k]
        for level, ratio in sorted(levels.items()):
            ratio *= detail
            if ratio >= 0.999:
                continue
            lock = level != "vem" and int(level[3:]) <= seam_lock
            key = (k, round(ratio, 5), lock)
            if key not in cache:
                dup = _make_copy(by_name[k], f"{k}__fsk_{level}", ratio, others, lock)
                created.append(dup)
                cache[key] = dup.name
            variants.setdefault(k, {})[level] = cache[key]
        if k in variants:
            log.append(f"LODs for {piece} ('{k}'): " + ", ".join(
                f"{lv}" + ("" if variants[k][lv].endswith(lv) else f"={variants[k][lv].split('__fsk_')[-1]}")
                for lv in sorted(variants[k])))
    return created, variants, log


def remove(objs):
    for o in objs:
        me = o.data
        bpy.data.objects.remove(o, do_unlink=True)
        if me and me.users == 0:
            bpy.data.meshes.remove(me)
