import bpy
from bpy.types import Panel

from . import state as S
from .operators import ICON


def _fold(layout, settings, prop, text):
    row = layout.row()
    row.prop(settings, prop, text=text, emboss=False,
             icon='DOWNARROW_HLT' if getattr(settings, prop) else 'RIGHTARROW')
    return getattr(settings, prop)


def _lines(layout, text, icon='INFO'):
    for i, line in enumerate(t for t in text.split("\n") if t):
        layout.label(text=line, icon=icon if i == 0 else 'BLANK1')


def _tile_note(layout, img):
    if img is None:
        return
    from . import textures as T
    try:
        path, note = T.source_path(img)
    except S.FskError as e:
        layout.label(text="     " + str(e).split(": ", 1)[-1][:90], icon='ERROR')
        return
    size = T.png_size(path) if path else None
    w = size[0] if size else img.size[0]
    if not w:
        return
    layout.label(text=f"     {w} px  ->  _$h {w}, _$m1 {w // 2}, base {w // 4}", icon='BLANK1')
    if note:
        layout.label(text=f"     {note}", icon='INFO')


class FSK_PT_main(Panel):
    bl_label = "Forspoken Export"
    bl_idname = "FSK_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Forspoken"

    def draw(self, context):
        layout = self.layout
        s = context.scene.fsk
        try:
            S.data_root()
            S.output_dir("x")
        except S.FskError as e:
            box = layout.box()
            _lines(box, str(e), 'ERROR')
            box.operator("preferences.addon_show", text="Open preferences").module = S.ADDON
            return
        layout.label(text="FSK 0.5.4", icon='INFO')
        layout.prop(s, "outfit", text="")
        col = layout.column(align=True)
        col.prop(s, "head_object")
        col.prop(s, "body_object")

        objs = S.selected_meshes(context)
        box = layout.box()
        box.label(text=f"Selected: {len(objs)} mesh(es)", icon='RESTRICT_SELECT_OFF')
        if objs:
            o_set = S.outfit_settings(s, s.outfit, create=False)
            labels = {m.obj: (m.label or m.target) for m in o_set.mappings} if o_set else {}
            for o in objs:
                row = box.row(align=True)
                row.label(text=o.name, icon='MESH_DATA')
                row.operator_menu_enum("fsk.pick_target", "target", text=labels.get(o.name, "auto")).obj = o.name

        row = layout.row(align=True)
        row.scale_y = 1.3
        row.operator("fsk.refresh_plan", icon='FILE_REFRESH')
        if _fold(layout, s, "show_plan", "Plan"):
            box = layout.box()
            if not s.rows:
                box.label(text="Press Refresh plan", icon='INFO')
            keep = S.keep_set(s, s.outfit)
            for r in s.rows:
                row = box.row(align=True)
                row.label(text=f"{r.action:8s}", icon=ICON.get(r.action, 'DOT'))
                sub = row.row()
                sub.label(text=r.piece)
                sub.label(text=r.material.replace(".gmtl", ""))
                if r.action == "remove" or r.key in keep:
                    row.operator("fsk.toggle_keep", text="", icon='PINNED' if r.key in keep else 'UNPINNED').key = r.key
                row = box.row()
                row.scale_y = 0.6
                row.label(text=f"     {r.reason}  ({r.lods} meshes)")
            if s.plan_errors:
                _lines(box, s.plan_errors, 'ERROR')
            if s.plan_info:
                _lines(box, s.plan_info, 'ERROR')

        if _fold(layout, s, "show_options", "Head & LODs"):
            box = layout.box()
            box.prop(s, "game_data")
            sub = box.row()
            sub.enabled = s.game_data
            sub.prop(s, "my_weights")
            box.separator()
            box.prop(s, "lods")
            col = box.column(align=True)
            col.enabled = s.lods
            col.prop(s, "lod_detail")
            col.prop(s, "seam_lock")
            col.prop(s, "vem")

        if _fold(layout, s, "show_material", "Body material"):
            box = layout.box()
            box.prop(s, "body_material")
            col = box.column(align=True)
            col.enabled = s.body_material
            col.prop(s, "master_uri", text="")
            col.prop(s, "mat_emissive")
            col.prop(s, "mat_rough0")
            col.prop(s, "mat_rough1")
            col.prop(s, "mat_spec0")
            col.prop(s, "mat_spec1")

        if _fold(layout, s, "show_textures", "Textures"):
            box = layout.box()
            box.prop(s, "textures")
            row = box.row(align=True)
            row.enabled = s.textures
            row.prop(s, "skin_separate", text="Shared skin in its own build:")
            sub = row.row(align=True)
            sub.enabled = s.skin_separate
            sub.prop(s, "skin_name", text="")
            col = box.column(align=True)
            col.enabled = s.textures
            col.label(text="Face (paths from the outfit's face material, _o remembered per outfit)")
            for suf in ("b", "n", "r", "s", "o"):
                col.template_ID(s, f"face_{suf}", open="image.open", text=f"_{suf}")
                _tile_note(col, getattr(s, f"face_{suf}"))
            col.separator()
            col.label(text="Body (paths from the master body material)")
            for suf in ("b", "n", "r", "s", "o"):
                col.template_ID(s, f"body_{suf}", open="image.open", text=f"_{suf}")
                _tile_note(col, getattr(s, f"body_{suf}"))
            box.operator("fsk.export_textures", icon='TEXTURE')

        col = layout.column(align=True)
        col.prop(s, "build_name", text="", placeholder=s.outfit if s.outfit != "NONE" else "build name",
                 icon='OUTLINER_COLLECTION')
        name = S.build_name(s, s.outfit)
        if s.build_name and name != s.build_name.strip():
            col.label(text=f"saved as: {name}", icon='INFO')
        row = layout.row(align=True)
        row.scale_y = 1.6
        row.operator("fsk.export", icon='EXPORT', text=f"Export '{name}' to Flagrum")
        layout.operator("fsk.open_output", icon='FILE_FOLDER')


class FSK_PT_hair(Panel):
    bl_label = "Hair Preview"
    bl_idname = "FSK_PT_hair"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Forspoken"

    def draw(self, context):
        from . import hair
        layout = self.layout
        s = context.scene.fsk
        col = layout.column(align=True)
        try:
            S.character_dir()
            has_data = True
        except S.FskError:
            has_data = False
        if has_data:
            row = col.row(align=True)
            row.prop(s, "hair_file", text="")
            row.operator("fsk.rescan_hair", text="", icon='FILE_REFRESH')
            row = col.row(align=True)
            row.scale_y = 1.3
            row.operator("fsk.show_hair", icon='CURVES')
        col.operator("fsk.import_hair", text="Import hair file...", icon='IMPORT')
        layout.prop(s, "hair_thickness")
        if hair.previews():
            layout.operator("fsk.remove_hair", icon='X')
        layout.label(text="Preview only - hair isn't exported", icon='INFO')


class FSK_PT_cleanup(Panel):
    bl_label = "Weights"
    bl_idname = "FSK_PT_cleanup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Forspoken"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        col = self.layout.column(align=True)
        col.operator("fsk.normalize_weights", icon='MOD_VERTEX_WEIGHT')
        col.operator("fsk.remove_empty_groups", icon='GROUP_VERTEX')


classes = (FSK_PT_main, FSK_PT_hair, FSK_PT_cleanup)
