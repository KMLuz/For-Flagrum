import bpy
from bpy.props import StringProperty, BoolProperty
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper

from .generate_armature import generate_armature
from .gmdlimporter import GmdlImporter
from .import_context import ImportContext
from .read_armature_data import import_armature_data


class FSK_OT_import_model(Operator, ImportHelper):
    """Import a Forspoken (Luminous) model"""
    bl_idname = "fsk.import_model"
    bl_label = "Import Forspoken Model (.gfxbin)"
    filename_ext = ".gfxbin"

    filter_glob: StringProperty(default="*.gfxbin", options={'HIDDEN'})
    import_lods: BoolProperty(name="Import LODs", description="Also import every LOD mesh", default=False)
    import_vems: BoolProperty(name="Import VEMs", description="Also import the VEM (low-poly proxy) meshes", default=False)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "import_lods")
        layout.prop(self, "import_vems")

    def execute(self, context):
        import_context = ImportContext(self.filepath, self.import_lods, self.import_vems)
        importer = GmdlImporter(import_context)
        importer.import_gfxbin()
        importer.generate_bone_table()

        if len(importer.bone_table) > 0 and import_context.amdl_path is None:
            self.report({'ERROR'}, "Missing armature (.amdl) file next to the model. Export the matching amdl "
                                   "into the same folder (its name must match the model).")
            return {'CANCELLED'}

        if len(importer.bone_table) > 0:
            armature_data = import_armature_data(import_context)
            if armature_data is not None:
                generate_armature(import_context, armature_data)

        importer.import_meshes()
        return {'FINISHED'}


def menu_import(self, context):
    self.layout.operator(FSK_OT_import_model.bl_idname, text="Forspoken model (.gfxbin)")
