import json
import os
import subprocess
import tempfile
from os.path import dirname, join, splitext
from types import SimpleNamespace



class Interop:

    @staticmethod
    def run_command(command):
        flagrum_path = join(dirname(__file__), "..", "lib", "Flagrum.Blender.exe")
        command = "\"" + flagrum_path + "\" " + command
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False)
        (output, error) = process.communicate()
        status = process.wait()

        if error is not None and status != 0:
            print(error.decode('UTF-8'))
            raise RuntimeError("An exception occured during the operation of Flagrum.Blender.exe")
        elif status == 0 and output != b'':
            print(output.decode('UTF-8'))

    @staticmethod
    def import_material_inputs(gfxbin_path) -> dict[str, list[float]]:
        tempfile_path = tempfile.NamedTemporaryFile().name + ".json"
        command = "material -i \"" + gfxbin_path + "\" -o \"" + tempfile_path + "\""
        Interop.run_command(command)

        import_file = open(tempfile_path, mode='r')
        import_data = import_file.read()

        data: dict[str, list[float]] = json.loads(import_data)

        import_file.close()
        os.remove(tempfile_path)
        return data

    @staticmethod
    def import_gpubin(gfxbin_path: str, import_lods: bool, import_vems: bool) -> bytes:
        tempfile_path = tempfile.NamedTemporaryFile().name + ".bin"
        command = f"gpubin \"{gfxbin_path}\" \"{tempfile_path}\" {str(import_lods)} {str(import_vems)}"
        Interop.run_command(command)

        import_file = open(tempfile_path, mode='rb')
        buffer = import_file.read()
        import_file.close()
        os.remove(tempfile_path)
        return buffer
