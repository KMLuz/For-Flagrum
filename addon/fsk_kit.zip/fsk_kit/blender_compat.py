"""Small compatibility helpers for supported Blender API generations.

Flagrum started on Blender 3.x.  Blender 4.0 changed node-group interfaces and
Blender 4.1 removed Mesh.use_auto_smooth; modern Blender also uses the newer
Separate/Combine Color nodes.  Keep these differences isolated here so the
import/export logic can remain the same on Blender 3.x and 5.x.
"""

import bpy


def selected_objects(context):
    """Return the selected objects using the supported context API."""
    return list(getattr(context, "selected_objects", ()) or ())


def set_custom_normals(mesh, normals):
    """Set per-vertex custom normals on both old and current Blender builds."""
    # Auto Smooth was removed in Blender 4.1.  Custom normals are honored
    # automatically by current Blender versions, so this is only needed on 3.x.
    if hasattr(mesh, "use_auto_smooth"):
        try:
            mesh.use_auto_smooth = True
        except (AttributeError, TypeError):
            pass
    mesh.normals_split_custom_set_from_vertices(normals)


def new_separate_rgb(nodes):
    """Create a channel-separation node with RGB behavior on Blender 3.x-5.x."""
    node_type = "ShaderNodeSeparateColor" if bpy.app.version >= (4, 0, 0) else "ShaderNodeSeparateRGB"
    node = nodes.new(node_type)
    if hasattr(node, "mode"):
        node.mode = "RGB"
    return node


def new_combine_rgb(nodes):
    """Create a channel-combination node with RGB behavior on Blender 3.x-5.x."""
    node_type = "ShaderNodeCombineColor" if bpy.app.version >= (4, 0, 0) else "ShaderNodeCombineRGB"
    node = nodes.new(node_type)
    if hasattr(node, "mode"):
        node.mode = "RGB"
    return node


def new_group_socket(node_tree, in_out, socket_type, name):
    """Add a node-group interface socket using the pre/post Blender 4.0 API."""
    if bpy.app.version >= (4, 0, 0) and hasattr(node_tree, "interface"):
        return node_tree.interface.new_socket(name=name, in_out=in_out, socket_type=socket_type)

    collection = node_tree.inputs if in_out == "INPUT" else node_tree.outputs
    return collection.new(socket_type, name)


def principled_input(principled, legacy_name):
    """Resolve Principled BSDF sockets whose names changed in Blender 4.0."""
    modern_names = {
        "Subsurface": "Subsurface Weight",
        "Transmission": "Transmission Weight",
        "Specular": "Specular IOR Level",
        "Coat": "Coat Weight",
        "Sheen": "Sheen Weight",
        "Emission": "Emission Color",
    }
    modern_name = modern_names.get(legacy_name, legacy_name)
    candidates = (modern_name, legacy_name) if bpy.app.version >= (4, 0, 0) else (legacy_name, modern_name)
    for name in candidates:
        socket = principled.inputs.get(name)
        if socket is not None:
            return socket
    raise KeyError("Principled BSDF input socket not found: {} / {}".format(legacy_name, modern_name))
