"""FSK - Forspoken Kit. Import Forspoken models, export Flagrum-ready builds.

Built on the Flagrum Blender add-on's model importer; the FFXV export, environment/terrain import, material
editor, parts system and auto-updater were removed.
"""
import bpy
from bpy.props import PointerProperty

from .import_export.menu import FSK_OT_import_model, menu_import
from .forspoken import operators, panel, props

bl_info = {
    "name": "FSK - Forspoken Kit",
    "author": "Luz (importer based on Flagrum by Kizari)",
    "version": (0, 5, 1),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Forspoken, File > Import",
    "description": "Import Forspoken models and export Flagrum-ready outfit builds",
    "category": "Import-Export",
}

classes = props.classes + operators.classes + panel.classes + (FSK_OT_import_model,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.fsk = PointerProperty(type=props.FSK_Settings)
    bpy.types.TOPBAR_MT_file_import.append(menu_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_import)
    del bpy.types.Scene.fsk
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
